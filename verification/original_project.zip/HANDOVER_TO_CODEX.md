# Rice_SapFlow_V01: 完整工程交接与开发指南 (Handover Document for Codex)

> **致接手工程师 / Codex Agent**：  
> 本文档是 **Rice_SapFlow_V01（水稻茎秆微型原位液流监测系统）** 的完整技术交接档案。  
> 硬件电路原理图、PCB 物理布局、DRC 验证、3D 光线追踪渲染、嘉立创 (JLCPCB) 生产制造文件（Gerber / BOM / CPL）均已全部设计完毕并通过校验。  
> 本指南梳理了硬件全貌、电气规范、器件编号、工艺红线，并列出了接下来的**固件开发 (Firmware)、热脉冲液流计算模型 (Algorithm)、野外低功耗与无线通信 (IoT)** 等工作任务。

---

## 一、项目背景与系统拓扑

本系统用于农田/温室环境下对水稻单株茎秆进行**微创/低侵入式原位高频液流速率（Sap Flow Velocity）连续测定**，用于水稻蒸腾规律、抗旱节水表型鉴定及精准灌溉决策。

系统采用“**分体协同式架构**”：
```
+---------------------------------------------------------------------------------+
|                         Main_Controller_V01 (主控板)                             |
|  [5V DC] ---> [ESP32-C3 Super Mini] ---> [AO3400A N-MOS] ---> [SJ1 3.3V/5V跳线]  |
|                     | I2C (GPIO0/1)              | HEATER_RETURN/VCC            |
+---------------------+----------------------------+------------------------------+
                      |                            |
                      | 6P 0.5mm 柔性排线 (FPC)    |
                      v                            v
+---------------------------------------------------------------------------------+
|                         Sensor_FPC_V01 (柔性针式探针)                            |
|       [J1_FPC 6P金手指 (0.3mm PI补强)]                                          |
|                     |                                                           |
|                     +---> TMP117_UP   (上游测温, I2C 0x48, 紧贴水稻茎秆基部)     |
|                     +---> PTC HEATER  (中央热脉冲激发, PRF18 470Ω)               |
|                     +---> TMP117_DOWN (下游测温, I2C 0x49, 顺流测定脉冲峰值响应)  |
|                                                                                 |
|       * 液流方向: 水稻根系 ---> TMP117_UP ---> PTC ---> TMP117_DOWN ---> 稻穗   |
+---------------------------------------------------------------------------------+
```

---

## 二、硬件设计与电气规格

### 2.1 主控板 (`Main_Controller_V01`)
- **板材规格**: 2-Layer FR-4，50.0 mm × 32.0 mm，板厚 1.6 mm，1 oz 铜厚，经典绿阻焊/白字，四角 4 × M3 安装定位孔。
- **主控模块 (`U1`)**: ESP32-C3 Super Mini 模块（板载 RISC-V 160MHz、Wi-Fi 4 & BLE 5、USB-C、3.3V LDO）。通过 2×8、2.54 mm 母排排针座插拔安装（引脚跨距 17.78 mm / 700 mil）。板载天线朝向外侧悬空净空。
- **引脚分配 (Pinout)**:
  - `GPIO0`: I²C SDA（外置 4.7 kΩ 贴片电阻 `R1` 上拉至 3.3V）
  - `GPIO1`: I²C SCL（外置 4.7 kΩ 贴片电阻 `R2` 上拉至 3.3V）
  - `GPIO3`: `HEATER_EN` 加热使能（经 100 Ω `R3` 驱动 MOSFET 栅极）
  - `GPIO10`: 预留测试引脚（引出至插座 `U1_R` Pin 6）
- **加热低边开关 (`Q1`)**:
  - 器件: AO3400A (SOT-23 N 沟道 MOSFET，30V / 5.7A，LCSC: **C20917**)
  - 电路连接: Gate 串联 100 Ω 阻尼电阻 `R3` 接 GPIO3，同时接 100 kΩ 下拉电阻 `R4` 到 GND 确保上电掉电死区安全；Source 直接连接 GND 主平面；Drain 连接 `HEATER_RETURN`。
- **供电切换跳线 (`SJ1`)**:
  - 3 焊盘 SMD 跳线：Pad 1 = 3.3V，Pad 2 = `HEATER_VCC`，Pad 3 = 5V。
  - 出厂默认状态：Pad 2 与 Pad 3 连锡短接（选择 5V 主供电加热，获得更高热脉冲功率；如需超低功耗或锂电池单路供电，可割断改接 1-2）。
- **FPC 接口 (`J1`)**:
  - 6P、0.5 mm 间距水平卧贴翻盖式 FPC/ZIF 插座（LCSC: **C6364657**）。
  - 固定引脚定义：
    - Pin 1: `3V3` (传感器逻辑与模拟供电)
    - Pin 2: `GND` (接地基准)
    - Pin 3: `SDA` (I²C 数据线)
    - Pin 4: `SCL` (I²C 时钟线)
    - Pin 5: `HEATER_VCC` (加热器高边供电, 5V 或 3.3V)
    - Pin 6: `HEATER_RETURN` (加热器低边开关回路, 接 Q1 Drain)
- **去耦与测试点**:
  - 5V 轨: `C1`(10 µF 0805, LCSC **C440198**) + `C2`(100 nF 0603, LCSC **C14663**)
  - 3.3V 轨: `C3`(10 µF 0805, LCSC **C440198**) + `C4`(100 nF 0603, LCSC **C14663**)
  - 测试点（SMD Pad D1.0mm）: `TP1`(5V)、`TP2`(3V3)、`TP3`(GND)、`TP4`(SDA)、`TP5`(SCL)、`TP6`(HEATER_RETURN)。

---

### 2.2 柔性传感器探针 (`Sensor_FPC_V01`)
- **板材规格**: 2-Layer 聚酰亚胺柔性板 (FPC)，PI 基材厚度 0.11 mm，0.5 oz (18 µm) 压延铜 (RA Cu)，黄色覆盖膜，**表面处理必须为 ENIG (沉金 2u")**。
- **探针针体外形**: 柳叶刀针式几何造型，探针尖端带 R0.5 倒角与锥形刃口，便于微创穿刺或贴紧水稻叶鞘包裹主茎。
- **核心元器件**:
  - `U1` (上游测温 TMP117_UP): WSON-6 (2×2 mm)，`ADD0` 接 GND，I²C 地址为 **`0x48`**。
  - `U2` (下游测温 TMP117_DOWN): WSON-6 (2×2 mm)，`ADD0` 接 3.3V，I²C 地址为 **`0x49`**。
  - `R_HEAT` (中央发热体): PRF18BC471RB5RB PTC 贴片热敏电阻 (0603 封装，常温标称阻值 470 Ω，居里点自限温防烧坏，LCSC: **C152572**)。
  - `C1, C2`: 100 nF 50V X7R 0402 去耦电容，分别紧贴 `U1` 与 `U2` 的 $V_+$ 与 GND。
  - `J1_FPC`: 尾端 6P 0.5 mm 沉金金手指。
- **三版本中心距规格对照**:
  | 版本名称 | 探针尺寸 (长×宽) | 中心距 $d$ | 跨距 $2d$ | 适用生长阶段与茎秆直径 | 热响应特性与流速敏感区间 |
  | :--- | :--- | :--- | :--- | :--- | :--- |
  | **Sensor_FPC_2MM** | 36.0 × 3.2 mm | 2.0 mm | 4.0 mm | 水稻苗期/分蘖期 (2.0 ~ 3.5 mm) | 脉冲时延极短（1~3s），微弱夜间液流与零流标定极灵敏 |
  | **Sensor_FPC_3MM** (推荐标准版) | 40.0 × 3.5 mm | 3.0 mm | 6.0 mm | 拔节初期/主茎 (3.5 ~ 6.0 mm) | 热比率法 (HRM) 最优线性响应区，白天蒸腾全范围覆盖 |
  | **Sensor_FPC_4MM** | 45.0 × 3.8 mm | 4.0 mm | 8.0 mm | 抽穗扬花/灌浆期粗茎 (6.0 ~ 9.0 mm) | 大量程高蒸腾（>30 cm/h），防止强对流脉冲过冲失真 |

---

## 三、关键工艺红线与制造控制要求 (Critical Constraints)

接手硬件修改或组织生产时，必须严格遵守以下物理与热学设计红线：

1. **传感区严禁任何大面积铺铜（Strict Thermal Keepout Zone）**:
   - 在 `TMP117_UP` ➔ `PTC` ➔ `TMP117_DOWN` 这一核心测定区域内，**全层严禁大面积铺地或敷设电源平面**！
   - 走线必须采用上下对称的 0.15 mm 微细引线。
   - **工程原理**: 铜的导热系数高达 $\approx 398\,\text{W/(m}\cdot\text{K)}$，而聚酰亚胺 (PI) 导热系数仅 $\approx 0.12\,\text{W/(m}\cdot\text{K)}$。若在此区域铺铜，加热器产生的热脉冲会沿铜箔迅速旁路短路至测温芯片，彻底淹没由水稻茎秆液流对流携带的热信号。
2. **TMP117 底部裸露热沉焊盘 (Exposed Thermal Pad)**:
   - PCB 表面保留 1.0 × 1.6 mm 铜焊盘用于植物接触导热；
   - **第一版钢网绝对不能开孔 (取消 Solder Paste Opening / 零焊锡膏)**；
   - **电气必须保持悬空 (Floating，不连接 GND)**。
   - **工程原理**: 防止手工焊接或回流焊时多余锡膏溢出短路邻近细小引脚，同时避免热沉直接搭铁形成非对称热沉汇。
3. **FPC 金手指插入端补强厚度 (Stiffener Thickness)**:
   - 金手指反面必须贴合聚酰亚胺 (PI) 补强板；
   - **金手指插拔端总厚度必须严格控制在 $0.30 \pm 0.03\text{ mm}$**，以精确配合主控板上的 0.5 mm 卧贴翻盖式 ZIF 插座锁合力矩。

---

## 四、项目全量文件目录与结构索引

所有文件现已存放在当前文件夹中：

```
/Users/zhangshuxuan/本地文稿/Rice_SapFlow_V01/
├── HANDOVER_TO_CODEX.md                      # [本文档] Codex / 工程师交接全景技术指南
├── Rice_SapFlow_V01_PCB_Delivery_Report.md   # PCB 交付综合报告（含各板详细规格说明）
├── Rice_SapFlow_V01_Schematic_Review.md      # 原理图人工复核报告（ERC、网络表、BOM核对清单）
│
├── Main_Controller_V01/                      # ===== 主控板工程目录 =====
│   ├── Main_Controller_V01.kicad_pcb         # 原生 KiCad PCB 布局布线文件
│   ├── Main_Controller_V01.kicad_pro         # KiCad 工程主文件
│   ├── Main_Controller_V01_Gerber.zip        # [可直接生产] 嘉立创一键下单 Gerber 压缩包
│   ├── BOM_Main_Controller_V01.csv          # 嘉立创 SMT 贴片物料清单 (包含 LCSC 编号)
│   ├── CPL_Main_Controller_V01.csv          # 嘉立创 SMT 贴片坐标清单 (Centroid / Pick & Place)
│   ├── Main_Controller_V01_3D.png           # 真实 3D 光线追踪渲染图
│   ├── Main_Controller_V01_DRC.rpt          # 设计规则检查报告
│   └── gerber/                               # 解压后的光绘与钻孔文件目录
│
├── Sensor_FPC_V01/                           # ===== 柔性传感器探针目录 =====
│   ├── Sensor_FPC_2MM/                      # 2mm 中心距探针子工程 (含 .kicad_pcb, Gerber.zip, BOM, CPL, 3D.png)
│   ├── Sensor_FPC_3MM/                      # 3mm 中心距探针子工程 (标准推荐版，含同上完整套件)
│   └── Sensor_FPC_4MM/                      # 4mm 中心距探针子工程 (含同上完整套件)
│
├── fabrication/                              # ===== 制造与下单指导 =====
│   └── JLCPCB_Fabrication_Guide.md           # 嘉立创 FR-4 硬板与 FPC 柔性板下单工艺参数详细说明
│
├── docs/                                     # ===== 高清矢量原理图与布局图纸 =====
│   ├── Main_Controller_V01_Schematic.svg / .png
│   ├── Main_Controller_V01_PCB_Layout.svg / .png
│   ├── Sensor_FPC_V01_Schematic.svg / .png
│   ├── Sensor_FPC_V01_PCB_Layout.svg / .png
│   ├── Rice_SapFlow_Sensor_Geometry_Layout.svg / .png
│   ├── gen_main.py                          # 主控图纸生成脚本
│   ├── gen_sensor.py                        # 传感器图纸生成脚本
│   └── gen_pcb_svgs.py                      # PCB 矢量图生成脚本
│
└── scripts/                                  # ===== 自动化构建脚本 =====
    ├── build_kicad_projects.py              # KiCad 10 Python API 板卡构建基础脚本
    └── generate_full_package.py             # 包含 Gerber/钻孔/BOM/CPL/3D 全量打包生成脚本
```

---

## 五、Codex 接手任务清单与开发指南 (Roadmap for Codex)

Codex 或后续软件开发人员进入后，主要负责基于 **ESP32-C3** 的嵌入式固件开发、液流脉冲解算算法以及野外超低功耗调度。以下是推荐的实施步骤：

### 任务 1：ESP32-C3 基础外设驱动与传感器通讯
1. **开发框架推荐**:
   - `ESP-IDF v5.x`（首选，低功耗与内存管理性能最佳）或 `PlatformIO + Arduino`。
2. **I²C 总线配置**:
   - SDA = `GPIO0`，SCL = `GPIO1`，总线频率建议设为 $400\text{ kHz}$（Fast Mode）。
3. **TMP117 驱动开发**:
   - 寄存器地址：
     - 温度寄存器：`0x00`（16-bit 有符号数，分辨率 $0.0078125^\circ\text{C} / \text{LSB}$，精度 $\pm 0.1^\circ\text{C}$）
     - 配置寄存器：`0x01`（推荐设为连续转换模式，平均采样次数设为 8 次平滑噪声）
   - 设备挂载：
     - 初始化并周期性读取 `0x48` (`TMP117_UP`) 与 `0x49` (`TMP117_DOWN`)。
     - 校验温差基线：常温静态下 $\Delta T = T_{\text{down}} - T_{\text{up}} \approx 0 \pm 0.02^\circ\text{C}$。

### 任务 2：热脉冲控制与液流速率算法解算 (HRM & HPV)
1. **加热脉冲时序控制 (GPIO3)**:
   - 驱动配置：GPIO3 设为普通推挽输出（或 PWM）。
   - 典型脉冲触发：拉高 GPIO3 持续 $t_{\text{pulse}} = 2.0 \sim 3.0\text{ s}$，随后立即拉低关断。
   - 采样时钟：在加热前 10 秒记录温度基线，加热开始后以 $10\text{ Hz}$（每 100 ms）高频采样两个传感器温度，持续 120 秒记录热波传递曲线。
2. **热比率法 (Heat Ratio Method, HRM) 算法实现**:
   - 针对对称布置探针（上游探针距加热器距离 $x_1 = d$，下游探针距加热器距离 $x_2 = d$）：
     $$V_h = \frac{k}{x} \ln\left(\frac{\Delta T_1}{\Delta T_2}\right) \times 3600\quad [\text{cm/h}]$$
     其中：
     - $k$ 为木质部热扩散率（典型值约为 $0.0025 \sim 0.0030\,\text{cm}^2/\text{s}$）；
     - $x$ 为探针间距（按版本选用 $0.2\,\text{cm}$、$0.3\,\text{cm}$ 或 $0.4\,\text{cm}$）；
     - $\Delta T_1$ 为下游探针在特定时间（如脉冲后 60~80s）相对初温的升温量；
     - $\Delta T_2$ 为上游探针在同一时刻相对初温的升温量。
   - **双向液流与反向流支持**: 若 $\Delta T_1 < \Delta T_2$，说明植物体内出现夜间水分逆流或水势回补，HRM 算法能原生支持负向液流测量。

### 任务 3：野外低功耗与休眠调度 (Power Management)
- **间歇测量策略**:
  - 测定周期建议设为 15 分钟或 30 分钟一次。
  - 每次测定激活时间约 90 秒，测定完毕将解算结果写入 Flash / RTC 内存。
  - ESP32-C3 进入 `Deep Sleep`（定时器唤醒），休眠电流 $< 15\,\mu\text{A}$。
- **锂电池续航评估**:
  - 单次加热脉冲能耗约：$P = \frac{V^2}{R} = \frac{5^2}{470} \approx 0.053\,\text{W}$，持续 3 秒能耗极微；
  - 配合 2000 mAh 单节 18650 锂电池及微型太阳能电池板，可实现野外数月免维护连续监测。

### 任务 4：数据无线上传 (IoT / Cloud)
- 可选通信通道：
  1. **ESP-NOW**: 多个稻田分株节点组成自组网，向田埂上的 4G 网关节点单跳广播，低开销、低功耗。
  2. **BLE 广播 / GATT**: 巡检人员手持手机 App 或平板近距离读取当天的蒸腾液流曲线。
  3. **Wi-Fi MQTT**: 农田配备 Wi-Fi 覆盖时直接推流至云端（如 ThingsBoard、阿里云 IoT 或自主 MQTT Broker）。

---

## 六、环境与工具使用参考

1. **KiCad 命令行工具 (macOS)**:
   - 路径：`/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli`
   - Python 解释器：`/Applications/KiCad/KiCad.app/Contents/Frameworks/Python.framework/Versions/3.9/bin/python3`
   - 重新执行全量生成的命令：
     ```bash
     cd /Users/zhangshuxuan/本地文稿/Rice_SapFlow_V01
     /Applications/KiCad/KiCad.app/Contents/Frameworks/Python.framework/Versions/3.9/bin/python3 scripts/generate_full_package.py
     ```
2. **嘉立创EDA专业版 (EasyEDA Pro)**:
   - 导入路径：菜单栏 -> **文件 (File) ➔ 导入 (Import) ➔ KiCad** -> 选择对应目录下的 `.kicad_pcb` 文件即可。
