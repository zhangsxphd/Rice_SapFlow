# Rice_SapFlow_V01 水稻茎秆微型原位液流监测系统

基于 ESP32-C3 控制核心与超高精度双温探针（TMP117）的微创式作物液流监测硬件系统。

## 快速导航

- 📘 **详细技术交接档案**: [HANDOVER_TO_CODEX.md](HANDOVER_TO_CODEX.md) （包含硬件拓扑、引脚分配、热比率法 HRM 算法公式与固件开发指导）
- 📄 **PCB 设计交付报告**: [Rice_SapFlow_V01_PCB_Delivery_Report.md](Rice_SapFlow_V01_PCB_Delivery_Report.md)
- 📝 **原理图复核报告与 BOM**: [Rice_SapFlow_V01_Schematic_Review.md](Rice_SapFlow_V01_Schematic_Review.md)
- 🏭 **嘉立创制造与 SMT 贴片下单说明**: [fabrication/JLCPCB_Fabrication_Guide.md](fabrication/JLCPCB_Fabrication_Guide.md)

## 硬件模块与下单文件速查

| 硬件设计 | 原生 PCB 文件 | 嘉立创一键下单 Gerber 包 | SMT 贴片 BOM | 贴片坐标 CPL | 3D 效果图 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **主控板** (Main Controller) | `Main_Controller_V01/Main_Controller_V01.kicad_pcb` | `Main_Controller_V01/Main_Controller_V01_Gerber.zip` | `Main_Controller_V01/BOM_Main_Controller_V01.csv` | `Main_Controller_V01/CPL_Main_Controller_V01.csv` | `Main_Controller_V01/Main_Controller_V01_3D.png` |
| **2mm 探针** (苗期分蘖) | `Sensor_FPC_V01/Sensor_FPC_2MM/Sensor_FPC_2MM.kicad_pcb` | `Sensor_FPC_V01/Sensor_FPC_2MM/Sensor_FPC_2MM_Gerber.zip` | `Sensor_FPC_V01/Sensor_FPC_2MM/BOM_Sensor_FPC_2MM.csv` | `Sensor_FPC_V01/Sensor_FPC_2MM/CPL_Sensor_FPC_2MM.csv` | `Sensor_FPC_V01/Sensor_FPC_2MM/Sensor_FPC_2MM_3D.png` |
| **3mm 探针** (标准推荐) | `Sensor_FPC_V01/Sensor_FPC_3MM/Sensor_FPC_3MM.kicad_pcb` | `Sensor_FPC_V01/Sensor_FPC_3MM/Sensor_FPC_3MM_Gerber.zip` | `Sensor_FPC_V01/Sensor_FPC_3MM/BOM_Sensor_FPC_3MM.csv` | `Sensor_FPC_V01/Sensor_FPC_3MM/CPL_Sensor_FPC_3MM.csv` | `Sensor_FPC_V01/Sensor_FPC_3MM/Sensor_FPC_3MM_3D.png` |
| **4mm 探针** (成熟粗茎) | `Sensor_FPC_V01/Sensor_FPC_4MM/Sensor_FPC_4MM.kicad_pcb` | `Sensor_FPC_V01/Sensor_FPC_4MM/Sensor_FPC_4MM_Gerber.zip` | `Sensor_FPC_V01/Sensor_FPC_4MM/BOM_Sensor_FPC_4MM.csv` | `Sensor_FPC_V01/Sensor_FPC_4MM/CPL_Sensor_FPC_4MM.csv` | `Sensor_FPC_V01/Sensor_FPC_4MM/Sensor_FPC_4MM_3D.png` |

## 目录结构

```
/Users/zhangshuxuan/本地文稿/Rice_SapFlow_V01/
├── README.md
├── HANDOVER_TO_CODEX.md
├── Rice_SapFlow_V01_PCB_Delivery_Report.md
├── Rice_SapFlow_V01_Schematic_Review.md
├── Main_Controller_V01/
├── Sensor_FPC_V01/
├── fabrication/
├── docs/
└── scripts/
```
