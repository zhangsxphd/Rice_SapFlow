# Rice_SapFlow_V01: 完整 PCB 设计、3D 渲染与制造交付报告

本工程针对水稻作物茎秆液流微型无损/微创测定需求，完成了 **Rice_SapFlow_V01** 项目的全套 PCB 设计与制造文件生成。工程包含两个独立但协同工作的硬件子系统：
1. **Main_Controller_V01**: 基于 ESP32-C3 Super Mini 插拔式主控模块的便携驱动与采集板（2层硬板 FR-4，50.0 mm × 32.0 mm）。
2. **Sensor_FPC_V01**: 基于双超高精度 TMP117 测温芯片与 PRF18 PTC 加热器的超薄柔性探针（2层柔性板 FPC，提供 2 mm、3 mm、4 mm 三种中心距版本）。

---

## 一、主控板设计交付 (Main_Controller_V01)

### 1.1 物理布局与 2D/3D 渲染
主控板采用 50.0 mm × 32.0 mm 紧凑矩形板框，四角带有 M3 机械固定孔，板厚 1.6 mm。ESP32-C3 Super Mini 通过 2×8、2.54 mm 母排座插拔连接，板载天线净空区伸出板外以保证 Wi-Fi/BLE 信号发射。

![Main_Controller_V01 2D PCB Layout](/Users/zhangshuxuan/.gemini/antigravity/brain/23dddcf2-99e2-453b-94ea-ac0a1d91cdae/Main_Controller_V01_PCB_Layout.png)

![Main_Controller_V01 3D Raytraced View](/Users/zhangshuxuan/.gemini/antigravity/brain/23dddcf2-99e2-453b-94ea-ac0a1d91cdae/Main_Controller_V01_3D.png)

### 1.2 核心电路实现与布线规范
- **低边加热开关**: 使用 AO3400A (SOT-23 N-MOSFET, `Q1`)。Drain 引脚连接 `HEATER_RETURN`，Source 紧贴底层 GND 主平面，Gate 串联 100 Ω 阻尼电阻 (`R3`) 接 ESP32-C3 的 GPIO3，并设 100 kΩ 下拉电阻 (`R4`) 到 GND。
- **供电电压跳线 (`SJ1`)**: 3焊盘 SMD 焊锡跳线，焊盘 1=3.3V，2=HEATER_VCC，3=5V。出厂默认 2-3 连锡短接（选择 5V 加热供电）。
- **FPC 连接器 (`J1`)**: 嘉立创常备水平翻盖式 6P、0.5 mm 间距 SMT 连接器（LCSC: **C6364657**），下出线插接设计。
- **去耦电容就近布局**: 5V 主供电配 `C1`(10 µF) + `C2`(100 nF)；3.3V 稳压轨配 `C3`(10 µF) + `C4`(100 nF)，紧靠排针引脚。
- **测试点 (`TP1` ~ `TP6`)**: 沿板右侧均匀分布 1.0 mm 贴片测试盘：5V、3V3、GND、SDA、SCL、HEATER_RETURN。

---

## 二、柔性传感器探针设计交付 (Sensor_FPC_V01)

### 2.1 物理布局与几何结构
传感器采用柳叶刀针式几何结构，尾端为 6P 0.5 mm 金手指插拔端（附带 0.2 mm PI 补强），前端为锥形微创插入式探针尖端。

![Sensor_FPC_V01 2D PCB Layout](/Users/zhangshuxuan/.gemini/antigravity/brain/23dddcf2-99e2-453b-94ea-ac0a1d91cdae/Sensor_FPC_V01_PCB_Layout.png)

![Sensor_FPC_V01 3D Raytraced View](/Users/zhangshuxuan/.gemini/antigravity/brain/23dddcf2-99e2-453b-94ea-ac0a1d91cdae/Sensor_FPC_3MM_3D.png)

### 2.2 三版本中心距规格对照
| 版本名称 | 探针长 × 宽 | 中心距 $d$ | 跨距 $2d$ | 适用生长阶段与茎秆直径 | 热响应特性与流速敏感区间 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Sensor_FPC_2MM** | 36.0 × 3.2 mm | 2.0 mm | 4.0 mm | 水稻苗期/分蘖期 (2.0 ~ 3.5 mm) | 脉冲时延极短（1~3s），微弱夜间液流与零流标定极灵敏 |
| **Sensor_FPC_3MM (标准)** | 40.0 × 3.5 mm | 3.0 mm | 6.0 mm | 拔节初期/主茎 (3.5 ~ 6.0 mm) | 热比率法 (HRM) 最优线性响应区，白天蒸腾全范围覆盖 |
| **Sensor_FPC_4MM** | 45.0 × 3.8 mm | 4.0 mm | 8.0 mm | 抽穗扬花/灌浆期粗茎 (6.0 ~ 9.0 mm) | 大量程高蒸腾（>30 cm/h），防止强对流脉冲过冲失真 |

### 2.3 关键热学与工艺红线
> [!IMPORTANT]
> 1. **严禁大面积铺铜**: 在 `TMP117_UP`、`PTC HEATER` 与 `TMP117_DOWN` 之间的传感区域，**绝对禁止铺设任何 GND 或电源铜皮**（已设立全层 Rule Area / Keepout Zone），走线采用上下对称 0.15 mm 微细差分引线，以阻断 PCB 轴向寄生热导。
> 2. **TMP117 裸露热沉焊盘 (Exposed Thermal Pad)**: PCB 表面保留 1.0 × 1.6 mm 铜焊盘用于植物茎秆热接触，但**钢网取消开孔（零焊锡膏）**，且**电气保持悬空 (Floating，不连接 GND)**。
> 3. **FPC 金手指补强 (Stiffener)**: 尾部金手指反面贴合 PI 补强板，指定插入端总厚度严格满足 **0.30 ± 0.03 mm**。

---

## 三、嘉立创 (JLCPCB) 制造下单与文件清单

### 3.1 生产制造与贴片文件路径
工程已自动打包生成生产级 Gerber、钻孔、BOM 和坐标文件（CPL）：

```
Rice_SapFlow_V01/
├── Main_Controller_V01/
│   ├── Main_Controller_V01.kicad_pcb         # 原生 PCB 设计文件
│   ├── Main_Controller_V01.kicad_pro         # 工程定义文件
│   ├── Main_Controller_V01_Gerber.zip        # 嘉立创一键下单 Gerber 压缩包
│   ├── BOM_Main_Controller_V01.csv          # SMT 贴片 BOM (含 LCSC 编号)
│   ├── CPL_Main_Controller_V01.csv          # SMT 贴片元器件坐标文件
│   ├── Main_Controller_V01_3D.png           # 3D 渲染图
│   └── Main_Controller_V01_DRC.rpt          # 设计规则检查报告
│
├── Sensor_FPC_V01/
│   ├── Sensor_FPC_2MM/                      # 2mm 中心距版探针
│   │   ├── Sensor_FPC_2MM.kicad_pcb
│   │   ├── Sensor_FPC_2MM_Gerber.zip
│   │   ├── BOM_Sensor_FPC_2MM.csv
│   │   └── CPL_Sensor_FPC_2MM.csv
│   ├── Sensor_FPC_3MM/                      # 3mm 中心距版探针 (标准版)
│   │   ├── Sensor_FPC_3MM.kicad_pcb
│   │   ├── Sensor_FPC_3MM_Gerber.zip
│   │   ├── BOM_Sensor_FPC_3MM.csv
│   │   └── CPL_Sensor_FPC_3MM.csv
│   └── Sensor_FPC_4MM/                      # 4mm 中心距版探针
│       ├── Sensor_FPC_4MM.kicad_pcb
│       ├── Sensor_FPC_4MM_Gerber.zip
│       ├── BOM_Sensor_FPC_4MM.csv
│       └── CPL_Sensor_FPC_4MM.csv
│
└── fabrication/
    └── JLCPCB_Fabrication_Guide.md           # 详细下单工艺参数指导
```

### 3.2 嘉立创EDA专业版 (EasyEDA Pro) 导入说明
1. 打开 **嘉立创EDA专业版** 客户端或网页版；
2. 点击菜单 **文件 (File) ➔ 导入 (Import) ➔ KiCad**；
3. 选择上述对应目录下的 `.kicad_pcb` 文件或直接导入 Gerber 包；
4. 系统将自动解析所有网络拓扑、器件封装与禁布区，即可在嘉立创EDA专业版中无缝进行二次编辑、在线 3D 预览或一键计价下单。
