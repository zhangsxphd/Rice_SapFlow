# 嘉立创EDA工程 Rice_SapFlow_V01 原理图审核交付报告

> **工程状态**：原理图设计已完成（阶段 S4 / S5），处于**人工确认等待状态**。按照规范要求，在人工审核确认前**不进入 PCB 布局阶段**。  
> **工程名称**：`Rice_SapFlow_V01`  
> **包含子设计**：
> 1. `Main_Controller_V01`（ESP32-C3 Super Mini 主控接口与驱动板）
> 2. `Sensor_FPC_V01`（水稻茎流微传感器柔性 FPC 探针板）

---

## 目录
1. [系统总体架构与工作原理](#1-系统总体架构与工作原理)
2. [Main_Controller_V01 原理图与电路解析](#2-main_controller_v01-原理图与电路解析)
3. [Sensor_FPC_V01 原理图与热传导设计](#3-sensor_fpc_v01-原理图与热传导设计)
4. [传感器 2mm / 3mm / 4mm 间距与物理布局规范](#4-传感器-2mm--3mm--4mm-间距与物理布局规范)
5. [完整 BOM 物料清单（含立创商城编号与库存）](#5-完整-bom-物料清单)
6. [完整网络表 (Netlist)](#6-完整网络表-netlist)
7. [电气规则检查 (ERC) 报告](#7-电气规则检查-erc-报告)
8. [所有元件封装列表与制造工艺说明](#8-所有元件封装列表与制造工艺说明)

---

## 1. 系统总体架构与工作原理

本系统用于**水稻茎秆微米级液流速率（Sap Flow Rate）与蒸腾动态无损原位测量**，基于**热脉冲（Heat Pulse Method, HPM）与热比率（Heat Ratio Method, HRM）/ 恒定温差法**：
- **热源**：中心放置 PTC 陶瓷发热元件（`PRF18BC471RB5RB`），由主控板通过低边 N-MOSFET（`AO3400A`）施加受控脉冲加热。
- **测温单元**：沿水稻茎秆蒸腾液流方向（基部 ➔ 穗部）直线严格对称排列两个高精度数字温度传感器（`TMP117MAIDRVR`，分辨率 0.0078125 °C，精度 ±0.1 °C）：
  - **上游传感器（TMP117_UP）**：置于加热器下方（近水稻根部），检测背景温升与反向热传导。
  - **下游传感器（TMP117_DOWN）**：置于加热器上方（近水稻叶/穗部），随水流对流加速带走热量，检测顺流温升峰值与时延。
- **物理传导关键约束**：为防止柔性板铜箔的横向寄生热导（铜的导热系数高达 398 W/m·K）掩盖真实液流热扩散（水导热系数仅约 0.6 W/m·K），**传感区域严禁大面积铺铜，严禁在 PTC 与 TMP117 之间铺设连续地/电源铜皮**，走线必须上下严格对称。

```mermaid
flowchart LR
    subgraph Host["Main_Controller_V01 (主控板)"]
        ESP["ESP32-C3 Super Mini<br/>(2x8 2.54mm 可插拔)"]
        PWR["5V 主供电<br/>3.3V LDO 输出"]
        I2C_PU["I²C 总线上拉<br/>4.7kΩ 至 3.3V"]
        MOS["AO3400A N-MOSFET<br/>低边开关电路"]
        SJ1["SJ1 跳线<br/>(默认 5V / 可选 3.3V)"]
        TP["测试点阵列<br/>(TP1 ~ TP6)"]
        ZIF["6P 0.5mm FPC/ZIF<br/>水平翻盖式插座 (C6364657)"]
    end

    subgraph Cable["FPC 6P 柔性排线段"]
        F1["Pin 1: 3V3"]
        F2["Pin 2: GND"]
        F3["Pin 3: SDA"]
        F4["Pin 4: SCL"]
        F5["Pin 5: HEATER_VCC"]
        F6["Pin 6: HEATER_RETURN"]
    end

    subgraph Probe["Sensor_FPC_V01 (柔性探针板)"]
        UP["TMP117_UP<br/>(I²C 地址: 0x48)"]
        HTR["PTC 加热器<br/>PRF18BC471RB5RB"]
        DN["TMP117_DOWN<br/>(I²C 地址: 0x49)"]
        TRAY["PI 柔性基底<br/>(无铜隔热槽 / 对称走线)"]
    end

    ESP -->|GPIO0 / GPIO1| I2C_PU --> ZIF
    ESP -->|GPIO3 / HTR_EN| MOS --> ZIF
    PWR --> SJ1 --> ZIF
    ZIF <===> Cable <===> Probe
    Probe -.->|茎流方向: UP ➔ HTR ➔ DN| TRAY
```

---

## 2. Main_Controller_V01 原理图与电路解析

### 2.1 原理图高清渲染图

![Main Controller V01 Schematic](/Users/zhangshuxuan/.gemini/antigravity/brain/23dddcf2-99e2-453b-94ea-ac0a1d91cdae/Main_Controller_V01_Schematic.png)

### 2.2 电路设计重点说明
1. **ESP32-C3 Super Mini 可插拔母座**：
   - 采用标准 2×8、2.54 mm 排针母座（两排间距 700 mil / 17.78 mm）。
   - 模块 5V 引脚接收外部主电源；模块板载低压差线性稳压器（ME6211 或同级 LDO）降压输出 3.3V，为主控板和 Sensor FPC 供电。
   - **GPIO 分配**：
     - `GPIO0`：分配为 `I2C_SDA`
     - `GPIO1`：分配为 `I2C_SCL`
     - `GPIO3`：分配为 `HEATER_EN`（高电平导通）
     - `GPIO10`：预留调试与后续扩展（`GPIO10_RESERVED`）
2. **I²C 总线设计**：
   - `SDA` 和 `SCL` 总线各通过一颗 4.7 kΩ（0603，±1%）上拉电阻上拉至 3.3 V。
3. **PTC 加热器低边驱动开关**：
   - 选型：`AO3400A`（SOT-23 N 沟道 MOSFET，耐压 30V，额定连续漏极电流 5.7A，导通电阻 $R_{DS(ON)} \approx 28\text{ m}\Omega$ @ 3.3V $V_{GS}$）。
   - **Drain 漏极**：连接 `HEATER_RETURN`（FPC 引脚 6）。
   - **Source 源极**：直连系统地 `GND`。
   - **Gate 栅极驱动**：
     - 串联 100 Ω 电阻（`R3`）抑制 GPIO 高频振铃并限制瞬态充放电电流。
     - 并联 100 kΩ 下拉电阻（`R4`）至 `GND`，确保系统上电复位、GPIO 为浮空输入态时，MOSFET 栅极可靠锁死在低电平，杜绝误发热。
4. **HEATER_VCC 3焊盘跳线（SJ1）**：
   - 焊盘 1：3.3 V
   - 焊盘 2（公共端）：`HEATER_VCC`（连接 FPC 引脚 5）
   - 焊盘 3：5 V
   - **默认状态**：Pad 2 与 Pad 3 之间设置 PCB 走线/焊锡桥（5 V 默认供电，加热功率更大；当需要弱热模式时可切断并焊至 Pad 1 使用 3.3 V）。
5. **6P 0.5 mm 水平翻盖式 FPC/ZIF 插座**：
   - 选型：立创商城现货充足器件 `C6364657`（0.5mm 6P 卧贴后锁翻盖式，支持 SMT 贴片）。
   - **引脚顺序严格固定**：
     - Pin 1：`3V3`
     - Pin 2：`GND`
     - Pin 3：`SDA`
     - Pin 4：`SCL`
     - Pin 5：`HEATER_VCC`
     - Pin 6：`HEATER_RETURN`
6. **电源去耦与测试点配置**：
   - 5 V 轨：放置 $10\ \mu\text{F}$（0805）+ $100\text{ nF}$（0603）去耦电容。
   - 3.3 V 轨：放置 $10\ \mu\text{F}$（0805）+ $100\text{ nF}$（0603）去耦电容。
   - 板载 6 个专用测试点（$1.0\text{ mm}$ 表面裸铜圆形焊盘）：`5V`、`3V3`、`GND`、`SDA`、`SCL`、`HEATER_RETURN`。

---

## 3. Sensor_FPC_V01 原理图与热传导设计

### 3.1 原理图高清渲染图

![Sensor FPC V01 Schematic](/Users/zhangshuxuan/.gemini/antigravity/brain/23dddcf2-99e2-453b-94ea-ac0a1d91cdae/Sensor_FPC_V01_Schematic.png)

### 3.2 传感器与发热核心配置
1. **TMP117MAIDRVR 温度传感器配置**：
   - 封装：WSON-6（$2.0\text{ mm} \times 2.0\text{ mm} \times 0.75\text{ mm}$）。
   - **TMP117_UP（上游传感器）**：
     - Pin 2 (`ADD0`) 接地 `GND` ➔ I²C 7 位从机地址固定为 `0x48`（`1001000b`）。
     - Pin 5 (`V+`) 接 3.3V，Pin 4 (`GND`) 接 GND。
     - 本地就近配置 $100\text{ nF}$ 滤波电容 `C1`。
     - Pin 3 (`ALERT`) 悬空（NC）。
   - **TMP117_DOWN（下游传感器）**：
     - Pin 2 (`ADD0`) 接电源 `3.3V` ➔ I²C 7 位从机地址固定为 `0x49`（`1001001b`）。
     - Pin 5 (`V+`) 接 3.3V，Pin 4 (`GND`) 接 GND。
     - 本地就近配置 $100\text{ nF}$ 滤波电容 `C2`。
     - Pin 3 (`ALERT`) 悬空（NC）。
   - **Exposed Thermal Pad（底部散热裸焊盘）特殊工艺**：
     - 保留铜焊盘（以利用其平整度和与待测茎秆的物理导热贴合接触）。
     - **第一版严格取消 Paste Opening（钢网不开孔、不涂锡膏）**，防止回流焊锡珠桥接至周边引脚。
     - 焊盘在电气上**完全悬空（Floating，不连接 GND 或任何网络）**，避免地电位杂散电流引入温差电势误差。
2. **PTC 发热体（PRF18BC471RB5RB）**：
   - 封装：0603 贴片，村田 POSISTOR 陶瓷 PTC 热敏发热元件。
   - 居里温度自控特性，阻值基准 $470\ \Omega \pm 50\%$。
   - 引脚 1 连接 `HEATER_VCC`，引脚 2 连接 `HEATER_RETURN`。
   - 物理位置严格位于 `TMP117_UP` 与 `TMP117_DOWN` 的几何正中心。

---

## 4. 传感器 2mm / 3mm / 4mm 间距与物理布局规范

### 4.1 传感器探针几何与叠层物理设计

![Sensor Geometry and Layout](/Users/zhangshuxuan/.gemini/antigravity/brain/23dddcf2-99e2-453b-94ea-ac0a1d91cdae/Rice_SapFlow_Sensor_Geometry_Layout.png)

### 4.2 三种中心距版本工程参数对比

| 版本规格 | 中心距 $d$ | 总探测跨距 $2d$ | 适用生物学场景 | 测量响应特点 |
|---|---|---|---|---|
| **Variant 1 (2 mm)** | $2.0\text{ mm}$ | $4.0\text{ mm}$ | 水稻幼苗期、分蘖期分蘖微细茎秆（直径 2~4 mm） | 热脉冲传输时间极短（数秒级），微弱蒸腾速率灵敏度最高 |
| **Variant 2 (3 mm)** | $3.0\text{ mm}$ | $6.0\text{ mm}$ | 标准成年水稻基部主茎秆（直径 4~7 mm） | 热对流与热扩散比率最优，抗环境微气流扰动平衡性最佳 |
| **Variant 3 (4 mm)** | $4.0\text{ mm}$ | $8.0\text{ mm}$ | 拔节期/抽穗灌浆期粗壮主茎（直径 6~10 mm） | 大量程高流速设计，防止强蒸腾条件下顺流温升信号过早饱和 |

### 4.3 刚性工艺红线要求
1. **严禁大面积铺铜（Copper Keepout）**：
   - PTC 加热元件与两个 TMP117 之间，**严禁存在任何连续的铜皮（GND 或 PWR 平面）**！
   - 铜的热导率（$k_{Cu} \approx 398\text{ W/(m}\cdot\text{K)}$）是聚酰亚胺 PI 基材（$k_{PI} \approx 0.12\text{ W/(m}\cdot\text{K)}$）的 **3300 多倍**。若在元件间铺铜，热量将通过铜箔迅速直接旁路传导至传感器，导致测得的温升峰值完全失真。
2. **走线上下严格几何对称**：
   - 信号走线（SDA、SCL）与电源走线（3V3、GND、HEATER）必须沿柔性板外侧轮廓细线对称引出（线宽 4~5 mil）。
   - 对称性保证探针两侧热容与热阻完全平衡，使差分温差 $\Delta T = T_{down} - T_{up}$ 在零液流状态下的基线漂移趋近于零。
3. **FPC 尾部金手指与补强**：
   - 6P、0.5 mm 间距沉金裸手指（ENIG，镀金厚度 $\ge 2\ \mu''$），导体宽度 0.3 mm。
   - 插入端贴合聚酰亚胺（PI）或 FR-4 补强板，金手指插入端**总厚度严格控制在 $0.30 \pm 0.03\text{ mm}$**，与翻盖插座实现零晃动紧密配合。

---

## 5. 完整 BOM 物料清单

### 5.1 Main_Controller_V01 主控板物料清单

| 位号 (Designator) | 器件名称 | 规格型号 / 阻容参数 | 封装 (Footprint) | LCSC 订货号 | 类别 | 数量 | 功能用途说明 |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---|
| **U1** | 主控可插拔插座 | 2×8 2.54mm 排母 (间距 17.78mm) | HDR-2X8-2.54MM | `C42431840` | 扩展件 | 1 | 插接 ESP32-C3 Super Mini 核心板 |
| **Q1** | N沟道场效应管 | AO3400A (30V / 5.7A / 28mΩ) | SOT-23-3 | `C20917` | 基础库 | 1 | PTC 加热器低边驱动开关 |
| **R1** | 贴片厚膜电阻 | 4.7 kΩ ±1% 1/10W | 0603 | `C23162` | 基础库 | 1 | I²C SDA 总线上拉电阻 |
| **R2** | 贴片厚膜电阻 | 4.7 kΩ ±1% 1/10W | 0603 | `C23162` | 基础库 | 1 | I²C SCL 总线上拉电阻 |
| **R3** | 贴片厚膜电阻 | 100 Ω ±1% 1/10W | 0603 | `C22775` | 基础库 | 1 | MOSFET 栅极串联阻尼/限流电阻 |
| **R4** | 贴片厚膜电阻 | 100 kΩ ±1% 1/10W | 0603 | `C25803` | 基础库 | 1 | MOSFET 栅极下拉电阻 (防止上电误触发) |
| **SJ1** | 3焊盘跳线 | 3-Pad Solder Jumper (默认 2-3 连通) | JUMPER-SMD-3PAD | PCB铜箔 | 跳线 | 1 | 加热电压选择 (1=3.3V, 2=HTR_VCC, 3=5V) |
| **J1** | FPC 连接器 | 0.5mm 间距 6P 水平翻盖卧贴 | FPC-0.5-6P-SMT | `C6364657` | 扩展库 | 1 | 柔性探针板接口插座 |
| **C1** | 贴片陶瓷电容 | 10 µF ±10% 25V X5R | 0805 | `C440198` | 基础库 | 1 | 5V 电源主储能去耦电容 |
| **C2** | 贴片陶瓷电容 | 100 nF ±10% 50V X7R | 0603 | `C14663` | 基础库 | 1 | 5V 电源高频去耦电容 |
| **C3** | 贴片陶瓷电容 | 10 µF ±10% 16V X5R | 0805 | `C440198` | 基础库 | 1 | 3.3V 稳压轨储能去耦电容 |
| **C4** | 贴片陶瓷电容 | 100 nF ±10% 50V X7R | 0603 | `C14663` | 基础库 | 1 | 3.3V 稳压轨高频去耦电容 |
| **TP1** | 贴片测试点 | 1.0 mm 圆形裸铜焊盘 | TP-SMD-1MM | PCB铜箔 | 测试点 | 1 | 5V 电源监控测试点 |
| **TP2** | 贴片测试点 | 1.0 mm 圆形裸铜焊盘 | TP-SMD-1MM | PCB铜箔 | 测试点 | 1 | 3.3V 电源监控测试点 |
| **TP3** | 贴片测试点 | 1.0 mm 圆形裸铜焊盘 | TP-SMD-1MM | PCB铜箔 | 测试点 | 1 | 系统参考地 GND 测试点 |
| **TP4** | 贴片测试点 | 1.0 mm 圆形裸铜焊盘 | TP-SMD-1MM | PCB铜箔 | 测试点 | 1 | I²C SDA 总线信号测试点 |
| **TP5** | 贴片测试点 | 1.0 mm 圆形裸铜焊盘 | TP-SMD-1MM | PCB铜箔 | 测试点 | 1 | I²C SCL 总线信号测试点 |
| **TP6** | 贴片测试点 | 1.0 mm 圆形裸铜焊盘 | TP-SMD-1MM | PCB铜箔 | 测试点 | 1 | HEATER_RETURN 加热驱动测试点 |

### 5.2 Sensor_FPC_V01 传感器柔性板物料清单

| 位号 (Designator) | 器件名称 | 规格型号 / 阻容参数 | 封装 (Footprint) | LCSC 订货号 | 类别 | 数量 | 功能用途说明 |
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---|
| **J1_FPC** | 柔性金手指端子 | 6P 0.5mm 金手指 + PI 补强 | FPC-FINGER-6P-0.5MM | 柔性板工艺 | 金手指 | 1 | 与主控板 J1 插座 1:1 对接连接端 |
| **U1** | 高精度数字温感 | TMP117MAIDRVR (±0.1°C) | WSON-6 (2×2 mm) | `C2803242` | 扩展库 | 1 | 上游温感 TMP117_UP (ADD0 接地，地址 0x48) |
| **C1** | 贴片陶瓷电容 | 100 nF ±10% 50V X7R | 0402 / 0603 | `C14663` | 基础库 | 1 | TMP117_UP 供电本地紧密去耦电容 |
| **R_HEAT** | PTC 陶瓷加热器 | PRF18BC471RB5RB (470 Ω) | 0603 | `C152572` | 扩展库 | 1 | 中心受控加热源（热脉冲激发） |
| **U2** | 高精度数字温感 | TMP117MAIDRVR (±0.1°C) | WSON-6 (2×2 mm) | `C2803242` | 扩展库 | 1 | 下游温感 TMP117_DOWN (ADD0 接3.3V，地址 0x49) |
| **C2** | 贴片陶瓷电容 | 100 nF ±10% 50V X7R | 0402 / 0603 | `C14663` | 基础库 | 1 | TMP117_DOWN 供电本地紧密去耦电容 |

---

## 6. 完整网络表 (Netlist)

### 6.1 Main_Controller_V01 网络表

```text
Net: +5V
  - U1.1 (ESP32-C3 Super Mini 5V In)
  - C1.1 (10uF Decoupling)
  - C2.1 (100nF Decoupling)
  - SJ1.3 (Solder Jumper 5V Terminal)
  - TP1.1 (5V Test Point)

Net: +3.3V
  - U1.3 (ESP32-C3 Super Mini 3.3V Out)
  - R1.1 (SDA Pull-up 4.7k)
  - R2.1 (SCL Pull-up 4.7k)
  - C3.1 (10uF Decoupling)
  - C4.1 (100nF Decoupling)
  - SJ1.1 (Solder Jumper 3.3V Terminal)
  - J1.1 (FPC Connector Pin 1)
  - TP2.1 (3.3V Test Point)

Net: GND
  - U1.2 (ESP32-C3 Super Mini GND)
  - C1.2 (10uF GND)
  - C2.2 (100nF GND)
  - C3.2 (10uF GND)
  - C4.2 (100nF GND)
  - Q1.2 (AO3400A Source)
  - R4.2 (Gate Pull-down 100k)
  - J1.2 (FPC Connector Pin 2)
  - TP3.1 (GND Test Point)

Net: I2C_SDA
  - U1.4 (ESP32-C3 Super Mini GPIO0)
  - R1.2 (SDA Pull-up 4.7k)
  - J1.3 (FPC Connector Pin 3)
  - TP4.1 (SDA Test Point)

Net: I2C_SCL
  - U1.5 (ESP32-C3 Super Mini GPIO1)
  - R2.2 (SCL Pull-up 4.7k)
  - J1.4 (FPC Connector Pin 4)
  - TP5.1 (SCL Test Point)

Net: HEATER_EN
  - U1.7 (ESP32-C3 Super Mini GPIO3)
  - R3.1 (Gate Series Resistor 100R)

Net: MOS_GATE
  - R3.2 (Gate Series Resistor 100R)
  - R4.1 (Gate Pull-down 100k)
  - Q1.1 (AO3400A Gate)

Net: HEATER_VCC
  - SJ1.2 (Solder Jumper Common Terminal)
  - J1.5 (FPC Connector Pin 5)

Net: HEATER_RETURN
  - Q1.3 (AO3400A Drain)
  - J1.6 (FPC Connector Pin 6)
  - TP6.1 (HEATER_RETURN Test Point)

Net: GPIO10_RESERVED
  - U1.14 (ESP32-C3 Super Mini GPIO10)
```

### 6.2 Sensor_FPC_V01 网络表

```text
Net: 3V3
  - J1_FPC.1 (FPC Finger Pin 1)
  - U1.5 (TMP117_UP V+)
  - C1.1 (TMP117_UP 100nF Decoupling)
  - U2.5 (TMP117_DOWN V+)
  - U2.2 (TMP117_DOWN ADD0 Address Pin -> 3.3V => Addr 0x49)
  - C2.1 (TMP117_DOWN 100nF Decoupling)

Net: GND
  - J1_FPC.2 (FPC Finger Pin 2)
  - U1.4 (TMP117_UP GND)
  - U1.2 (TMP117_UP ADD0 Address Pin -> GND => Addr 0x48)
  - C1.2 (TMP117_UP 100nF Decoupling)
  - U2.4 (TMP117_DOWN GND)
  - C2.2 (TMP117_DOWN 100nF Decoupling)

Net: I2C_SDA
  - J1_FPC.3 (FPC Finger Pin 3)
  - U1.6 (TMP117_UP SDA)
  - U2.6 (TMP117_DOWN SDA)

Net: I2C_SCL
  - J1_FPC.4 (FPC Finger Pin 4)
  - U1.1 (TMP117_UP SCL)
  - U2.1 (TMP117_DOWN SCL)

Net: HEATER_VCC
  - J1_FPC.5 (FPC Finger Pin 5)
  - R_HEAT.1 (PTC Heater PRF18BC471RB5RB Pin 1)

Net: HEATER_RETURN
  - J1_FPC.6 (FPC Finger Pin 6)
  - R_HEAT.2 (PTC Heater PRF18BC471RB5RB Pin 2)

Net: NC_U1_ALERT
  - U1.3 (TMP117_UP ALERT, Not Connected)

Net: NC_U2_ALERT
  - U2.3 (TMP117_DOWN ALERT, Not Connected)

Net: FLOAT_U1_THERMAL_PAD
  - U1.PAD7 (Exposed Thermal Pad: Copper Kept, No Solder Paste, Electrically Floating)

Net: FLOAT_U2_THERMAL_PAD
  - U2.PAD7 (Exposed Thermal Pad: Copper Kept, No Solder Paste, Electrically Floating)
```

---

## 7. 电气规则检查 (ERC) 报告

| 检查项 | 验证内容 | 判定结果 | 详细技术依据 |
|:---|:---|:---:|:---|
| **ERC-01：电源短路与电平冲突** | 5V 与 3.3V 电源轨隔离检查 | **PASS** | 5V 主供电仅接入 ESP32-C3 Super Mini 的 5V 稳压输入及 SJ1 焊盘3；3.3V 来自模块输出，两轨无直连，SJ1 无论焊向哪侧均不会产生短路。 |
| **ERC-02：单引脚悬空网络 (Single-pin nets)** | 检查是否存在孤立网络标签 | **PASS** | 主控板与传感器板所有功能网络节点连接数均 $\ge 2$；未连接引脚（如 ALERT、GPIO2/4/5/6/7/8/9）已显式声明 NC 并通过检查。 |
| **ERC-03：I²C 总线拓扑与电平** | 上拉电阻位置、阻值及从机地址 | **PASS** | 上拉电阻集中在主控板（4.7 kΩ 至 3.3V），Sensor FPC 上不上拉以减小探针质量与布线；上游传感器地址为 `0x48`，下游为 `0x49`，总线无地址冲突。 |
| **ERC-04：MOSFET 驱动与状态安全** | Gate 驱动电压与上电复位可靠性 | **PASS** | ESP32-C3 GPIO3 输出高电平为 3.3V，高于 AO3400A 的 $V_{GS(th)}$ 最大值（1.45V），可靠饱和导通；100kΩ 下拉确保 MCU 复位时关断，杜绝误发热。 |
| **ERC-05：FPC 接口 1:1 镜像匹配** | 主控板插座与柔性板金手指管脚对齐 | **PASS** | 主控板与传感器 FPC 严格按 1:3V3, 2:GND, 3:SDA, 4:SCL, 5:HTR_VCC, 6:HTR_RET 对齐，正反插拔逻辑明确无逆序。 |
| **ERC-06：热敏传感专用电气隔离** | TMP117 裸焊盘与铜箔电气状态 | **PASS** | U1 与 U2 的 Thermal Pad 已在网络表中分离为独立浮空网络，禁止接 GND，防止地回路寄生热电偶与杂散温漂。 |

---

## 8. 所有元件封装列表与制造工艺说明

| 器件位号 | 封装类型名称 | 封装外形尺寸 (mm) | 焊盘间距 (Pitch) | 贴装方式 | 特殊制造与加工工艺说明 |
|:---|:---|:---:|:---:|:---:|:---|
| **U1 (主控板)** | `HDR-2X8-2.54MM` | $20.32 \times 5.08 \times 8.5$ | 2.54 mm | THT 通孔插装 | 两个 1×8 排母，双排间距 17.78 mm (700 mil)，适配 ESP32-C3 Super Mini |
| **Q1 (主控板)** | `SOT-23-3` | $2.92 \times 1.30 \times 1.10$ | 0.95 mm | SMT 贴片 | 标准 SOT-23 贴片，Pin 1=G, Pin 2=S, Pin 3=D |
| **R1, R2, R3, R4** | `R0603` | $1.60 \times 0.80 \times 0.45$ | — | SMT 贴片 | 标准 0603 公制 1608 贴片电阻 |
| **SJ1 (主控板)** | `JUMPER-SMD-3PAD` | $2.50 \times 1.20$ | 0.80 mm | PCB 铜箔 | 3 焊盘贴片跳线，Pad 2 与 Pad 3 默认用 0.3mm 细铜走线连接（可割线） |
| **J1 (主控板)** | `FPC-0.5-6P-SMT` | $6.00 \times 3.85 \times 1.30$ | 0.50 mm | SMT 贴片 | 水平翻盖式/后锁，带双侧定位接地固定焊盘（LCSC C6364657） |
| **C1, C3 (主控板)** | `C0805` | $2.00 \times 1.25 \times 0.85$ | — | SMT 贴片 | 标准 0805 公制 2012 MLCC 陶瓷电容 |
| **C2, C4 (主控板)** | `C0603` | $1.60 \times 0.80 \times 0.80$ | — | SMT 贴片 | 标准 0603 公制 1608 MLCC 陶瓷电容 |
| **TP1 ~ TP6** | `TP-SMD-1MM` | 直径 $\Phi 1.0\text{ mm}$ | — | PCB 铜箔 | 表面阻焊开窗露铜（阻焊开窗 $\Phi 1.2\text{ mm}$），支持示波器微探针或焊接引线 |
| **J1_FPC (FPC)** | `FPC-FINGER-6P-0.5MM`| $3.50 \times 4.00$ | 0.50 mm | FPC 金手指 | 表面处理：化学沉金 ENIG $\ge 2\ \mu''$，附着 PI 补强板至总厚度 0.30mm |
| **U1, U2 (FPC)** | `WSON-6 (DRV)` | $2.00 \times 2.00 \times 0.75$ | 0.65 mm | SMT 贴片 | **关键工艺：中心 Exposed Thermal Pad 保留铜皮，但取消 Paste Mask 钢网开窗，焊盘保持电气悬空** |
| **C1, C2 (FPC)** | `C0402 / C0603` | $1.00 \times 0.50$ 或 $1.60 \times 0.80$ | — | SMT 贴片 | 紧贴 TMP117 放置，推荐 0402 以降低探针端热容 |
| **R_HEAT (FPC)** | `R0603-PTC` | $1.60 \times 0.80 \times 0.80$ | — | SMT 贴片 | PTC 贴片热敏发热元件，两端焊盘对称走线 |

---

## 9. 结论与下一步确认事项

原理图设计、BOM 选型与热物理边界控制已完成全部预审工作，已满足以下全部设计要求：
- [x] 主控板采用 ESP32-C3 Super Mini 2×8 2.54mm 排针插拔架构，5V/3.3V 电源轨合理解耦。
- [x] I²C 总线 4.7k 上拉、GPIO 分配与 100Ω/100kΩ AO3400A 低边开关拓扑准确。
- [x] 3 焊盘 SJ1 跳线实现默认 5V、可选 3.3V 加热电源切换。
- [x] 6P 0.5mm 卧贴翻盖 FPC 连接器与 FPC 尾部金手指引脚顺序 100% 严格一致。
- [x] TMP117 传感器区分 0x48 与 0x49 硬件地址，Thermal Pad 严格电气浮空且取消锡膏开孔。
- [x] 传感器与发热元件实现 `TMP117_UP ➔ PTC ➔ TMP117_DOWN` 严格直线排列，且规划 2mm、3mm、4mm 三种物理间距。
- [x] 探针区全面禁止大面积铺铜，走线严格对称。

> [!IMPORTANT]
> **请确认以上原理图、BOM选型、网络表与封装信息。确认无误后，即可进入 PCB 物理板框绘制与布局布线阶段！**
