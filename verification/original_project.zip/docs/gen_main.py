import os

def generate_main_controller_svg(filepath):
    svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1400 950" width="1400" height="950" style="background:#ffffff; font-family:'Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,Helvetica,Arial,sans-serif;">
  <defs>
    <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#f0f2f5" stroke-width="1"/>
    </pattern>
    <marker id="dot" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6">
      <circle cx="5" cy="5" r="3" fill="#1e40af"/>
    </marker>
    <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-opacity="0.08"/>
    </filter>
  </defs>

  <!-- Background -->
  <rect width="100%" height="100%" fill="#ffffff"/>
  <rect width="100%" height="100%" fill="url(#grid)"/>

  <!-- Title Block & Frame -->
  <rect x="25" y="25" width="1350" height="900" fill="none" stroke="#334155" stroke-width="2"/>
  <rect x="27" y="27" width="1346" height="896" fill="none" stroke="#cbd5e1" stroke-width="1"/>

  <!-- Title Box -->
  <rect x="950" y="835" width="425" height="90" fill="#f8fafc" stroke="#334155" stroke-width="1.5"/>
  <line x1="950" y1="865" x2="1375" y2="865" stroke="#cbd5e1" stroke-width="1"/>
  <line x1="950" y1="895" x2="1375" y2="895" stroke="#cbd5e1" stroke-width="1"/>
  <line x1="1160" y1="865" x2="1160" y2="925" stroke="#cbd5e1" stroke-width="1"/>
  <text x="965" y="855" font-size="14" font-weight="bold" fill="#0f172a">PROJECT: Rice_SapFlow_V01</text>
  <text x="965" y="883" font-size="12" fill="#475569">TITLE: Main_Controller_V01 Schematic</text>
  <text x="1175" y="883" font-size="12" fill="#475569">REV: V1.0</text>
  <text x="965" y="913" font-size="11" fill="#64748b">STAGE: S4 Schematic Audit (Pre-PCB)</text>
  <text x="1175" y="913" font-size="11" fill="#64748b">DATE: 2026-10-02</text>

  <!-- Zone 1: ESP32-C3 Super Mini Module -->
  <rect x="50" y="60" width="480" height="740" rx="8" fill="#ffffff" stroke="#3b82f6" stroke-width="1.5" stroke-dasharray="6,4" filter="url(#shadow)"/>
  <rect x="50" y="60" width="480" height="35" rx="8" fill="#eff6ff"/>
  <text x="70" y="84" font-size="14" font-weight="bold" fill="#1d4ed8">MODULE 1: ESP32-C3 Super Mini (2x8 2.54mm Pluggable Socket)</text>

  <!-- ESP32-C3 Super Mini IC Body -->
  <rect x="150" y="120" width="280" height="640" rx="6" fill="#f8fafc" stroke="#1e293b" stroke-width="2"/>
  <text x="290" y="150" text-anchor="middle" font-size="16" font-weight="bold" fill="#0f172a">ESP32-C3 Super Mini</text>
  <text x="290" y="170" text-anchor="middle" font-size="11" fill="#64748b">2x8 Pin Headers (2.54 mm Pitch)</text>
  <rect x="230" y="185" width="120" height="40" rx="3" fill="#e2e8f0" stroke="#94a3b8"/>
  <text x="290" y="210" text-anchor="middle" font-size="10" fill="#475569">Type-C / RF Ant</text>

  <!-- Left Header Pins (J_MCU_L) -->
  <!-- 1: 5V -->
  <line x1="100" y1="260" x2="150" y2="260" stroke="#dc2626" stroke-width="2"/>
  <circle cx="100" cy="260" r="4" fill="#dc2626"/>
  <text x="160" y="265" font-size="11" font-weight="bold" fill="#dc2626">1: 5V (VBUS_IN)</text>
  <text x="85" y="255" font-size="10" font-weight="bold" fill="#dc2626">+5V</text>

  <!-- 2: GND -->
  <line x1="100" y1="320" x2="150" y2="320" stroke="#1e293b" stroke-width="2"/>
  <circle cx="100" cy="320" r="4" fill="#1e293b"/>
  <text x="160" y="325" font-size="11" font-weight="bold" fill="#1e293b">2: GND</text>
  <text x="85" y="315" font-size="10" font-weight="bold" fill="#1e293b">GND</text>

  <!-- 3: 3V3 -->
  <line x1="100" y1="380" x2="150" y2="380" stroke="#2563eb" stroke-width="2"/>
  <circle cx="100" cy="380" r="4" fill="#2563eb"/>
  <text x="160" y="385" font-size="11" font-weight="bold" fill="#2563eb">3: 3V3 (LDO_OUT)</text>
  <text x="85" y="375" font-size="10" font-weight="bold" fill="#2563eb">+3.3V</text>

  <!-- 4: GPIO0 (SDA) -->
  <line x1="430" y1="260" x2="560" y2="260" stroke="#0891b2" stroke-width="2"/>
  <circle cx="560" cy="260" r="4" fill="#0891b2"/>
  <text x="420" y="265" text-anchor="end" font-size="11" font-weight="bold" fill="#0891b2">4: GPIO0 (SDA)</text>
  <text x="570" y="265" font-size="11" font-weight="bold" fill="#0891b2">I2C_SDA</text>

  <!-- 5: GPIO1 (SCL) -->
  <line x1="430" y1="320" x2="560" y2="320" stroke="#0891b2" stroke-width="2"/>
  <circle cx="560" cy="320" r="4" fill="#0891b2"/>
  <text x="420" y="325" text-anchor="end" font-size="11" font-weight="bold" fill="#0891b2">5: GPIO1 (SCL)</text>
  <text x="570" y="325" font-size="11" font-weight="bold" fill="#0891b2">I2C_SCL</text>

  <!-- 6: GPIO2 -->
  <line x1="100" y1="440" x2="150" y2="440" stroke="#94a3b8" stroke-width="1.5"/>
  <text x="160" y="445" font-size="11" fill="#64748b">6: GPIO2 (NC)</text>

  <!-- 7: GPIO3 (HEATER_EN) -->
  <line x1="430" y1="380" x2="560" y2="380" stroke="#ea580c" stroke-width="2"/>
  <circle cx="560" cy="380" r="4" fill="#ea580c"/>
  <text x="420" y="385" text-anchor="end" font-size="11" font-weight="bold" fill="#ea580c">7: GPIO3 (HTR_EN)</text>
  <text x="570" y="385" font-size="11" font-weight="bold" fill="#ea580c">HEATER_EN</text>

  <!-- 8: GPIO4 -->
  <line x1="100" y1="500" x2="150" y2="500" stroke="#94a3b8" stroke-width="1.5"/>
  <text x="160" y="505" font-size="11" fill="#64748b">8: GPIO4 (NC)</text>

  <!-- Right Header Pins -->
  <text x="420" y="445" text-anchor="end" font-size="11" fill="#64748b">GPIO5 (NC) :9</text>
  <text x="420" y="505" text-anchor="end" font-size="11" fill="#64748b">GPIO6 (NC) :10</text>
  <text x="420" y="565" text-anchor="end" font-size="11" fill="#64748b">GPIO7 (NC) :11</text>
  <text x="420" y="625" text-anchor="end" font-size="11" fill="#64748b">GPIO8 (NC) :12</text>
  <text x="420" y="685" text-anchor="end" font-size="11" fill="#64748b">GPIO9 (NC) :13</text>
  <line x1="430" y1="740" x2="560" y2="740" stroke="#6366f1" stroke-width="2"/>
  <circle cx="560" cy="740" r="4" fill="#6366f1"/>
  <text x="420" y="745" text-anchor="end" font-size="11" font-weight="bold" fill="#6366f1">14: GPIO10 (RESERVE)</text>
  <text x="570" y="745" font-size="11" font-weight="bold" fill="#6366f1">GPIO10_RESERVED</text>


  <!-- Zone 2: I2C Bus Pull-ups &amp; Power Decoupling -->
  <rect x="580" y="60" width="360" height="380" rx="8" fill="#ffffff" stroke="#0891b2" stroke-width="1.5" stroke-dasharray="6,4" filter="url(#shadow)"/>
  <rect x="580" y="60" width="360" height="35" rx="8" fill="#ecfeff"/>
  <text x="600" y="84" font-size="14" font-weight="bold" fill="#0e7490">MODULE 2: I²C Pull-ups &amp; Power Rails</text>

  <!-- 3.3V Power Rail for Pullups -->
  <line x1="680" y1="130" x2="840" y2="130" stroke="#2563eb" stroke-width="2"/>
  <text x="760" y="120" text-anchor="middle" font-size="12" font-weight="bold" fill="#2563eb">+3.3V</text>
  <polygon points="760,105 753,115 767,115" fill="#2563eb"/>

  <!-- R1: 4.7k Pullup SDA -->
  <line x1="710" y1="130" x2="710" y2="160" stroke="#0891b2" stroke-width="2"/>
  <rect x="695" y="160" width="30" height="60" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
  <text x="710" y="195" text-anchor="middle" font-size="10" font-weight="bold" fill="#0f172a">4.7k</text>
  <text x="685" y="180" text-anchor="end" font-size="11" font-weight="bold" fill="#0284c7">R1</text>
  <line x1="710" y1="220" x2="710" y2="260" stroke="#0891b2" stroke-width="2"/>
  <circle cx="710" cy="260" r="4" fill="#0891b2"/>
  <line x1="560" y1="260" x2="900" y2="260" stroke="#0891b2" stroke-width="2"/>
  <text x="910" y="265" font-size="11" font-weight="bold" fill="#0891b2">I2C_SDA</text>

  <!-- R2: 4.7k Pullup SCL -->
  <line x1="810" y1="130" x2="810" y2="160" stroke="#0891b2" stroke-width="2"/>
  <rect x="795" y="160" width="30" height="60" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
  <text x="810" y="195" text-anchor="middle" font-size="10" font-weight="bold" fill="#0f172a">4.7k</text>
  <text x="835" y="180" font-size="11" font-weight="bold" fill="#0284c7">R2</text>
  <line x1="810" y1="220" x2="810" y2="320" stroke="#0891b2" stroke-width="2"/>
  <circle cx="810" cy="320" r="4" fill="#0891b2"/>
  <line x1="560" y1="320" x2="900" y2="320" stroke="#0891b2" stroke-width="2"/>
  <text x="910" y="325" font-size="11" font-weight="bold" fill="#0891b2">I2C_SCL</text>

  <!-- Power Decoupling Caps -->
  <!-- 5V Rail: C1 10uF + C2 100nF -->
  <text x="610" y="360" font-size="11" font-weight="bold" fill="#dc2626">5V Filter:</text>
  <line x1="680" y1="360" x2="680" y2="380" stroke="#dc2626" stroke-width="1.5"/>
  <line x1="670" y1="380" x2="690" y2="380" stroke="#0f172a" stroke-width="2"/>
  <line x1="670" y1="386" x2="690" y2="386" stroke="#0f172a" stroke-width="2"/>
  <line x1="680" y1="386" x2="680" y2="410" stroke="#1e293b" stroke-width="1.5"/>
  <text x="655" y="390" font-size="9" fill="#475569">C1:10uF</text>

  <line x1="740" y1="360" x2="740" y2="380" stroke="#dc2626" stroke-width="1.5"/>
  <line x1="730" y1="380" x2="750" y2="380" stroke="#0f172a" stroke-width="2"/>
  <line x1="730" y1="386" x2="750" y2="386" stroke="#0f172a" stroke-width="2"/>
  <line x1="740" y1="386" x2="740" y2="410" stroke="#1e293b" stroke-width="1.5"/>
  <text x="755" y="390" font-size="9" fill="#475569">C2:100nF</text>

  <!-- 3.3V Rail: C3 10uF + C4 100nF -->
  <text x="780" y="360" font-size="11" font-weight="bold" fill="#2563eb">3.3V Filter:</text>
  <line x1="850" y1="360" x2="850" y2="380" stroke="#2563eb" stroke-width="1.5"/>
  <line x1="840" y1="380" x2="860" y2="380" stroke="#0f172a" stroke-width="2"/>
  <line x1="840" y1="386" x2="860" y2="386" stroke="#0f172a" stroke-width="2"/>
  <line x1="850" y1="386" x2="850" y2="410" stroke="#1e293b" stroke-width="1.5"/>
  <text x="825" y="390" font-size="9" fill="#475569">C3:10uF</text>

  <line x1="900" y1="360" x2="900" y2="380" stroke="#2563eb" stroke-width="1.5"/>
  <line x1="890" y1="380" x2="910" y2="380" stroke="#0f172a" stroke-width="2"/>
  <line x1="890" y1="386" x2="910" y2="386" stroke="#0f172a" stroke-width="2"/>
  <line x1="900" y1="386" x2="900" y2="410" stroke="#1e293b" stroke-width="1.5"/>
  <text x="915" y="390" font-size="9" fill="#475569">C4:100nF</text>

  <!-- GND bar for caps -->
  <line x1="660" y1="410" x2="920" y2="410" stroke="#1e293b" stroke-width="1.5"/>
  <line x1="790" y1="410" x2="790" y2="425" stroke="#1e293b" stroke-width="1.5"/>
  <line x1="780" y1="425" x2="800" y2="425" stroke="#1e293b" stroke-width="2"/>
  <line x1="783" y1="429" x2="797" y2="429" stroke="#1e293b" stroke-width="1.5"/>
  <line x1="787" y1="433" x2="793" y2="433" stroke="#1e293b" stroke-width="1"/>


  <!-- Zone 3: Heater Power Selector & Low-Side MOSFET Switch -->
  <rect x="580" y="470" width="360" height="330" rx="8" fill="#ffffff" stroke="#ea580c" stroke-width="1.5" stroke-dasharray="6,4" filter="url(#shadow)"/>
  <rect x="580" y="470" width="360" height="35" rx="8" fill="#fff7ed"/>
  <text x="600" y="494" font-size="14" font-weight="bold" fill="#c2410c">MODULE 3: Heater Switch &amp; SJ1 Jumper</text>

  <!-- SJ1 Solder Jumper (3-Pad) -->
  <rect x="620" y="525" width="220" height="75" rx="6" fill="#f8fafc" stroke="#94a3b8" stroke-width="1"/>
  <text x="630" y="545" font-size="11" font-weight="bold" fill="#0f172a">SJ1 (Solder Jumper 3-Pad)</text>
  <!-- Pad 1: 3.3V -->
  <rect x="645" y="555" width="35" height="30" rx="3" fill="#eff6ff" stroke="#2563eb" stroke-width="1.5"/>
  <text x="662" y="575" text-anchor="middle" font-size="10" font-weight="bold" fill="#2563eb">1</text>
  <text x="662" y="600" text-anchor="middle" font-size="9" fill="#2563eb">3.3V</text>
  <!-- Pad 2: Common (HEATER_VCC) -->
  <rect x="710" y="555" width="35" height="30" rx="3" fill="#fef2f2" stroke="#dc2626" stroke-width="1.5"/>
  <text x="727" y="575" text-anchor="middle" font-size="10" font-weight="bold" fill="#dc2626">2</text>
  <text x="727" y="600" text-anchor="middle" font-size="9" font-weight="bold" fill="#dc2626">HTR_VCC</text>
  <!-- Pad 3: 5V (Default Solder Bridge) -->
  <rect x="775" y="555" width="35" height="30" rx="3" fill="#fef2f2" stroke="#dc2626" stroke-width="1.5"/>
  <text x="792" y="575" text-anchor="middle" font-size="10" font-weight="bold" fill="#dc2626">3</text>
  <text x="792" y="600" text-anchor="middle" font-size="9" fill="#dc2626">5V (Def)</text>
  <!-- Solder bridge trace between 2 & 3 -->
  <path d="M 745 570 Q 760 562 775 570" fill="none" stroke="#ea580c" stroke-width="4"/>
  <text x="760" y="550" text-anchor="middle" font-size="9" font-weight="bold" fill="#ea580c">Default Bridge</text>

  <!-- Trace out of Pad 2 to HEATER_VCC -->
  <line x1="727" y1="585" x2="727" y2="620" stroke="#dc2626" stroke-width="2"/>
  <line x1="727" y1="620" x2="900" y2="620" stroke="#dc2626" stroke-width="2"/>
  <circle cx="900" cy="620" r="4" fill="#dc2626"/>
  <text x="910" y="625" font-size="11" font-weight="bold" fill="#dc2626">HEATER_VCC</text>

  <!-- MOSFET AO3400A Low-Side Circuit -->
  <line x1="560" y1="380" x2="620" y2="380" stroke="#ea580c" stroke-width="2"/>
  <line x1="620" y1="380" x2="620" y2="690" stroke="#ea580c" stroke-width="2"/>
  <line x1="620" y1="690" x2="650" y2="690" stroke="#ea580c" stroke-width="2"/>

  <!-- R3: 100 Ohm Gate Resistor -->
  <rect x="650" y="678" width="45" height="24" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
  <text x="672" y="694" text-anchor="middle" font-size="10" font-weight="bold" fill="#0f172a">100Ω</text>
  <text x="672" y="670" text-anchor="middle" font-size="10" font-weight="bold" fill="#ea580c">R3</text>
  <line x1="695" y1="690" x2="745" y2="690" stroke="#ea580c" stroke-width="2"/>
  <circle cx="730" cy="690" r="3.5" fill="#ea580c"/>

  <!-- R4: 100k Gate Pull-down -->
  <line x1="730" y1="690" x2="730" y2="720" stroke="#ea580c" stroke-width="2"/>
  <rect x="718" y="720" width="24" height="45" fill="#ffffff" stroke="#0f172a" stroke-width="1.5"/>
  <text x="730" y="746" text-anchor="middle" font-size="9" font-weight="bold" fill="#0f172a">100k</text>
  <text x="705" y="745" font-size="10" font-weight="bold" fill="#ea580c">R4</text>
  <line x1="730" y1="765" x2="730" y2="785" stroke="#1e293b" stroke-width="1.5"/>
  <!-- GND -->
  <line x1="720" y1="785" x2="740" y2="785" stroke="#1e293b" stroke-width="2"/>
  <line x1="723" y1="789" x2="737" y2="789" stroke="#1e293b" stroke-width="1.5"/>
  <line x1="726" y1="793" x2="734" y2="793" stroke="#1e293b" stroke-width="1"/>

  <!-- Q1: AO3400A Symbol -->
  <rect x="745" y="650" width="85" height="80" rx="4" fill="#f8fafc" stroke="#1e293b" stroke-width="1.5"/>
  <text x="787" y="668" text-anchor="middle" font-size="10" font-weight="bold" fill="#0f172a">Q1: AO3400A</text>
  <text x="787" y="682" text-anchor="middle" font-size="9" fill="#64748b">SOT-23 N-MOS</text>
  <!-- Gate, Drain, Source pins -->
  <line x1="745" y1="690" x2="765" y2="690" stroke="#ea580c" stroke-width="2"/>
  <text x="752" y="705" font-size="9" font-weight="bold" fill="#ea580c">G</text>
  <!-- Drain out to top -->
  <line x1="787" y1="650" x2="787" y2="635" stroke="#ea580c" stroke-width="2"/>
  <line x1="787" y1="635" x2="900" y2="635" stroke="#ea580c" stroke-width="2"/>
  <text x="795" y="645" font-size="9" font-weight="bold" fill="#ea580c">D</text>
  <circle cx="900" cy="635" r="4" fill="#ea580c"/>
  <text x="910" y="640" font-size="11" font-weight="bold" fill="#ea580c">HEATER_RETURN</text>
  <!-- Source to GND -->
  <line x1="787" y1="730" x2="787" y2="785" stroke="#1e293b" stroke-width="2"/>
  <text x="795" y="745" font-size="9" font-weight="bold" fill="#1e293b">S</text>
  <!-- GND -->
  <line x1="777" y1="785" x2="797" y2="785" stroke="#1e293b" stroke-width="2"/>
  <line x1="780" y1="789" x2="794" y2="789" stroke="#1e293b" stroke-width="1.5"/>
  <line x1="784" y1="793" x2="790" y2="793" stroke="#1e293b" stroke-width="1"/>


  <!-- Zone 4: FPC 6P 0.5mm ZIF Connector -->
  <rect x="970" y="60" width="380" height="420" rx="8" fill="#ffffff" stroke="#10b981" stroke-width="1.5" stroke-dasharray="6,4" filter="url(#shadow)"/>
  <rect x="970" y="60" width="380" height="35" rx="8" fill="#ecfdf5"/>
  <text x="990" y="84" font-size="14" font-weight="bold" fill="#047857">MODULE 4: J1 FPC/ZIF 6P 0.5mm Connector</text>

  <!-- Connector J1 Body -->
  <rect x="1050" y="120" width="220" height="330" rx="6" fill="#f8fafc" stroke="#047857" stroke-width="2"/>
  <text x="1160" y="150" text-anchor="middle" font-size="15" font-weight="bold" fill="#065f46">J1: FPC-0.5-6P</text>
  <text x="1160" y="170" text-anchor="middle" font-size="11" fill="#047857">Horizontal Flip-Lock SMT (C6364657)</text>

  <!-- Pin 1: 3V3 -->
  <line x1="900" y1="200" x2="1050" y2="200" stroke="#2563eb" stroke-width="2"/>
  <circle cx="1050" cy="200" r="4" fill="#2563eb"/>
  <text x="1065" y="205" font-size="12" font-weight="bold" fill="#2563eb">Pin 1: 3V3</text>
  <text x="1030" y="195" font-size="10" font-weight="bold" fill="#2563eb">+3.3V</text>

  <!-- Pin 2: GND -->
  <line x1="900" y1="240" x2="1050" y2="240" stroke="#1e293b" stroke-width="2"/>
  <circle cx="1050" cy="240" r="4" fill="#1e293b"/>
  <text x="1065" y="245" font-size="12" font-weight="bold" fill="#1e293b">Pin 2: GND</text>
  <text x="1030" y="235" font-size="10" font-weight="bold" fill="#1e293b">GND</text>

  <!-- Pin 3: SDA -->
  <line x1="900" y1="280" x2="1050" y2="280" stroke="#0891b2" stroke-width="2"/>
  <circle cx="1050" cy="280" r="4" fill="#0891b2"/>
  <text x="1065" y="285" font-size="12" font-weight="bold" fill="#0891b2">Pin 3: SDA</text>
  <text x="1025" y="275" font-size="10" font-weight="bold" fill="#0891b2">I2C_SDA</text>

  <!-- Pin 4: SCL -->
  <line x1="900" y1="320" x2="1050" y2="320" stroke="#0891b2" stroke-width="2"/>
  <circle cx="1050" cy="320" r="4" fill="#0891b2"/>
  <text x="1065" y="325" font-size="12" font-weight="bold" fill="#0891b2">Pin 4: SCL</text>
  <text x="1025" y="315" font-size="10" font-weight="bold" fill="#0891b2">I2C_SCL</text>

  <!-- Pin 5: HEATER_VCC -->
  <line x1="900" y1="360" x2="1050" y2="360" stroke="#dc2626" stroke-width="2.5"/>
  <circle cx="1050" cy="360" r="4" fill="#dc2626"/>
  <text x="1065" y="365" font-size="12" font-weight="bold" fill="#dc2626">Pin 5: HEATER_VCC</text>
  <text x="990" y="355" font-size="10" font-weight="bold" fill="#dc2626">HEATER_VCC</text>

  <!-- Pin 6: HEATER_RETURN -->
  <line x1="900" y1="400" x2="1050" y2="400" stroke="#ea580c" stroke-width="2.5"/>
  <circle cx="1050" cy="400" r="4" fill="#ea580c"/>
  <text x="1065" y="405" font-size="12" font-weight="bold" fill="#ea580c">Pin 6: HEATER_RETURN</text>
  <text x="975" y="395" font-size="10" font-weight="bold" fill="#ea580c">HEATER_RETURN</text>

  <!-- Note on FPC Pitch -->
  <text x="1160" y="435" text-anchor="middle" font-size="10" fill="#64748b">Pitch: 0.5 mm | Pin 1-6 Fixed Order</text>


  <!-- Zone 5: Dedicated Test Points Array -->
  <rect x="970" y="510" width="380" height="290" rx="8" fill="#ffffff" stroke="#8b5cf6" stroke-width="1.5" stroke-dasharray="6,4" filter="url(#shadow)"/>
  <rect x="970" y="510" width="380" height="35" rx="8" fill="#f5f3ff"/>
  <text x="990" y="534" font-size="14" font-weight="bold" fill="#6d28d9">MODULE 5: Test Points Array (TP1~TP6)</text>

  <g transform="translate(1000, 560)">
    <!-- TP1: 5V -->
    <circle cx="40" cy="30" r="14" fill="#fee2e2" stroke="#dc2626" stroke-width="2"/>
    <circle cx="40" cy="30" r="5" fill="#dc2626"/>
    <text x="40" y="62" text-anchor="middle" font-size="11" font-weight="bold" fill="#dc2626">TP1: 5V</text>

    <!-- TP2: 3V3 -->
    <circle cx="110" cy="30" r="14" fill="#dbeafe" stroke="#2563eb" stroke-width="2"/>
    <circle cx="110" cy="30" r="5" fill="#2563eb"/>
    <text x="110" y="62" text-anchor="middle" font-size="11" font-weight="bold" fill="#2563eb">TP2: 3V3</text>

    <!-- TP3: GND -->
    <circle cx="180" cy="30" r="14" fill="#f1f5f9" stroke="#1e293b" stroke-width="2"/>
    <circle cx="180" cy="30" r="5" fill="#1e293b"/>
    <text x="180" y="62" text-anchor="middle" font-size="11" font-weight="bold" fill="#1e293b">TP3: GND</text>

    <!-- TP4: SDA -->
    <circle cx="40" cy="120" r="14" fill="#cffafe" stroke="#0891b2" stroke-width="2"/>
    <circle cx="40" cy="120" r="5" fill="#0891b2"/>
    <text x="40" y="152" text-anchor="middle" font-size="11" font-weight="bold" fill="#0891b2">TP4: SDA</text>

    <!-- TP5: SCL -->
    <circle cx="110" cy="120" r="14" fill="#cffafe" stroke="#0891b2" stroke-width="2"/>
    <circle cx="110" cy="120" r="5" fill="#0891b2"/>
    <text x="110" y="152" text-anchor="middle" font-size="11" font-weight="bold" fill="#0891b2">TP5: SCL</text>

    <!-- TP6: HEATER_RETURN -->
    <circle cx="200" cy="120" r="14" fill="#ffedd5" stroke="#ea580c" stroke-width="2"/>
    <circle cx="200" cy="120" r="5" fill="#ea580c"/>
    <text x="200" y="152" text-anchor="middle" font-size="11" font-weight="bold" fill="#ea580c">TP6: HTR_RET</text>

    <text x="160" y="200" text-anchor="middle" font-size="11" fill="#64748b">SMD Test Points: 1.0 mm Dia. Pad (Copper Exposed)</text>
  </g>

</svg>'''
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(svg)

generate_main_controller_svg('/Users/zhangshuxuan/Documents/antigravity/peaceful-noether/docs/Main_Controller_V01_Schematic.svg')
print("Main_Controller_V01_Schematic.svg generated.")
