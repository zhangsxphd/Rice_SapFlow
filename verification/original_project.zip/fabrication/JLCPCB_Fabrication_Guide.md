# Rice_SapFlow_V01 嘉立创 (JLCPCB) 制造与 SMT 贴片下单工艺指导

本项目包含两个硬件设计，分别对应不同的 PCB 制造工艺与下单要求：

---

## 一、主控板 (Main_Controller_V01) 制造规范

### 1.1 PCB 基础参数 (Rigid PCB)
- **板材类型 (Material)**: FR-4 标准环氧玻璃布层压板
- **板层结构 (Layers)**: 双层板 (2-Layer)
- **外形尺寸 (Dimensions)**: 50.0 mm × 32.0 mm (公差 ±0.15 mm)
- **成品板厚 (Thickness)**: 1.6 mm
- **铜箔厚度 (Finished Copper)**: 1 oz (35 µm)
- **阻焊颜色 (Solder Mask)**: 经典绿色 (Green) 或哑光黑
- **字符颜色 (Silkscreen)**: 白色 (White)
- **表面处理 (Surface Finish)**: 有铅喷锡 (HASL) 或 沉金 (ENIG)
- **最小线宽/线距 (Min Trace/Space)**: 8 mil / 8 mil (走线设计裕量充分)
- **最小钻孔 (Min Hole)**: 0.3 mm (过孔外径 0.6 mm)
- **机械安装孔**: 4 × M3 通孔 (孔径 3.2 mm，盘径 6.0 mm，距板边 4.0 mm)

### 1.2 SMT 贴片工艺
- **贴片面**: 顶层单面贴片 (Top Side Only)
- **贴片器件**:
  - `Q1`: AO3400A (SOT-23, LCSC: **C20917**) - 嘉立创基础库 (Basic Part)
  - `R1, R2`: 4.7 kΩ ±1% 0603 (LCSC: **C23162**) - 基础库
  - `R3`: 100 Ω ±1% 0603 (LCSC: **C22775**) - 基础库
  - `R4`: 100 kΩ ±1% 0603 (LCSC: **C25803**) - 基础库
  - `C1, C3`: 10 µF 25V X5R 0805 (LCSC: **C440198**) - 基础库
  - `C2, C4`: 100 nF 50V X7R 0603 (LCSC: **C14663**) - 基础库
  - `J1`: 6P 0.5 mm 卧贴翻盖式 FPC 座 (LCSC: **C6364657**) - 扩展库 (Extended Part)
- **插件后焊器件**:
  - `U1_L, U1_R`: 2.54 mm 1×8 母排 (LCSC: **C42431840** / **C2905417**)
- **跳线初始状态**:
  - `SJ1`: 焊盘 2-3 默认连锡短接 (HEATER_VCC 选择 5V 供电)

---

## 二、柔性传感器探针 (Sensor_FPC_V01) 制造规范

### 2.1 柔性板基础参数 (Flex PCB)
- **板材类型 (Type)**: 双层柔性板 (2-Layer FPC)
- **基材膜厚 (Base Polyimide)**: 0.11 mm 聚酰亚胺 (PI)
- **铜箔类型**: 0.5 oz (18 µm) 压延铜 (RA Copper，耐反复弯折)
- **覆盖膜类型 (Coverlay)**: 黄色聚酰亚胺覆盖膜 (Yellow Coverlay)
- **表面处理 (Finish)**: **沉金 (ENIG 2u")** (必须选用沉金，以确保 0.5 mm 金手指耐磨性及 WSON-6 焊盘共面度)
- **补强板 (Stiffener)**:
  - **位置**: FPC 尾端金手指背面 (Bottom Layer)
  - **材质**: PI 补强 (Polyimide Stiffener)
  - **关键厚度控制**: 补强后金手指插入端**总厚度严格控制在 0.30 ± 0.03 mm**，确保与主控板 0.5 mm ZIF 翻盖连接器紧密压合锁紧。

### 2.2 探针尺寸规格 (三版本)
| 版本名称 | 探针长度 × 宽度 | 中心距 d (UP-PTC-DN) | 总跨距 2d | 适用作物与茎秆规格 |
| :--- | :--- | :--- | :--- | :--- |
| **Sensor_FPC_2MM** | 36.0 mm × 3.2 mm | 2.0 mm | 4.0 mm | 水稻苗期/分蘖期 (茎径 2.0 ~ 3.5 mm) |
| **Sensor_FPC_3MM** (推荐标准版) | 40.0 mm × 3.5 mm | 3.0 mm | 6.0 mm | 拔节初期/主茎 (茎径 3.5 ~ 6.0 mm) |
| **Sensor_FPC_4MM** | 45.0 mm × 3.8 mm | 4.0 mm | 8.0 mm | 抽穗扬花/粗茎 (茎径 6.0 ~ 9.0 mm) |

### 2.3 关键热学与焊接控制 (Critical Assembly Notices)
1. **TMP117 Exposed Pad 工艺要求**:
   - TMP117 (WSON-6) 底部的热沉焊盘 (Exposed Thermal Pad) 在 PCB 上保留裸铜导热，但**第一版钢网严禁开孔 (取消 Solder Paste Opening)**，且**电气保持悬空 (Floating，不连接 GND)**。
   - 目的：防止回流焊锡珠将热沉电气短路，同时避免形成对地铜皮热分流。
2. **严禁大面积铺铜**:
   - 传感区域 (UP ➔ PTC ➔ DOWN) **绝对禁止大面积铜箔铺地或覆铜**，仅保留 0.15 mm 微细差分对称走线，最大程度减少沿 FPC 基材的横向轴向热短路。

---

## 三、嘉立创 EDA 专业版 (EasyEDA Pro) 导入与使用指引

如果需要在 EasyEDA Pro 客户端或网页版中打开/二次编辑本工程：
1. 启动 **嘉立创EDA专业版** 并登录账户；
2. 点击顶部菜单栏：**文件 (File) ➔ 导入 (Import) ➔ KiCad**；
3. 选择对应的 PCB 文件：
   - 主控板: `Rice_SapFlow_V01/Main_Controller_V01/Main_Controller_V01.kicad_pcb`
   - 传感器: `Rice_SapFlow_V01/Sensor_FPC_V01/Sensor_FPC_3MM/Sensor_FPC_3MM.kicad_pcb`
4. EasyEDA Pro 会自动解析封装、网络拓扑、走线、板框、焊盘与禁布区，并无缝载入。

---

## 四、一键下单制造文件清单

| 文件路径 | 对应设计 | 用途 |
| :--- | :--- | :--- |
| `Rice_SapFlow_V01/Main_Controller_V01/Main_Controller_V01_Gerber.zip` | 主控板 | 嘉立创 PCB 生产 Gerber 压缩包 |
| `Rice_SapFlow_V01/Main_Controller_V01/BOM_Main_Controller_V01.csv` | 主控板 | 嘉立创 SMT 贴片物料清单 |
| `Rice_SapFlow_V01/Main_Controller_V01/CPL_Main_Controller_V01.csv` | 主控板 | 嘉立创 SMT 贴片元器件坐标文件 |
| `Rice_SapFlow_V01/Sensor_FPC_V01/Sensor_FPC_2MM/Sensor_FPC_2MM_Gerber.zip` | 2mm 探针 | 嘉立创 FPC 柔性板 Gerber 压缩包 |
| `Rice_SapFlow_V01/Sensor_FPC_V01/Sensor_FPC_3MM/Sensor_FPC_3MM_Gerber.zip` | 3mm 探针 (标准) | 嘉立创 FPC 柔性板 Gerber 压缩包 |
| `Rice_SapFlow_V01/Sensor_FPC_V01/Sensor_FPC_4MM/Sensor_FPC_4MM_Gerber.zip` | 4mm 探针 | 嘉立创 FPC 柔性板 Gerber 压缩包 |
| `Rice_SapFlow_V01/Sensor_FPC_V01/Sensor_FPC_3MM/BOM_Sensor_FPC_3MM.csv` | 传感器探针 | 嘉立创 SMT 贴片物料清单 |
| `Rice_SapFlow_V01/Sensor_FPC_V01/Sensor_FPC_3MM/CPL_Sensor_FPC_3MM.csv` | 传感器探针 | 嘉立创 SMT 贴片坐标清单 |
