import os
import sys
import pcbnew

FOOTPRINT_BASE = '/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints/'

def add_edge_cuts_rect(board, x0, y0, x1, y1, radius=0):
    """Draw a rectangle outline on Edge.Cuts with optional corner chamfer/fillet."""
    x0_i = pcbnew.FromMM(x0)
    y0_i = pcbnew.FromMM(y0)
    x1_i = pcbnew.FromMM(x1)
    y1_i = pcbnew.FromMM(y1)
    r_i = pcbnew.FromMM(radius)

    if radius <= 0:
        pts = [
            (pcbnew.VECTOR2I(x0_i, y0_i), pcbnew.VECTOR2I(x1_i, y0_i)),
            (pcbnew.VECTOR2I(x1_i, y0_i), pcbnew.VECTOR2I(x1_i, y1_i)),
            (pcbnew.VECTOR2I(x1_i, y1_i), pcbnew.VECTOR2I(x0_i, y1_i)),
            (pcbnew.VECTOR2I(x0_i, y1_i), pcbnew.VECTOR2I(x0_i, y0_i)),
        ]
        for p_start, p_end in pts:
            seg = pcbnew.PCB_SHAPE(board)
            seg.SetShape(pcbnew.SHAPE_T_SEGMENT)
            seg.SetLayer(pcbnew.Edge_Cuts)
            seg.SetStart(p_start)
            seg.SetEnd(p_end)
            seg.SetWidth(pcbnew.FromMM(0.1))
            board.Add(seg)
    else:
        # Corner rounded rect
        pts = [
            # Top edge
            (pcbnew.VECTOR2I(x0_i + r_i, y0_i), pcbnew.VECTOR2I(x1_i - r_i, y0_i)),
            # Right edge
            (pcbnew.VECTOR2I(x1_i, y0_i + r_i), pcbnew.VECTOR2I(x1_i, y1_i - r_i)),
            # Bottom edge
            (pcbnew.VECTOR2I(x1_i - r_i, y1_i), pcbnew.VECTOR2I(x0_i + r_i, y1_i)),
            # Left edge
            (pcbnew.VECTOR2I(x0_i, y1_i - r_i), pcbnew.VECTOR2I(x0_i, y0_i + r_i)),
            # Corners (45 deg chamfer for clean CAD outline)
            (pcbnew.VECTOR2I(x1_i - r_i, y0_i), pcbnew.VECTOR2I(x1_i, y0_i + r_i)),
            (pcbnew.VECTOR2I(x1_i, y1_i - r_i), pcbnew.VECTOR2I(x1_i - r_i, y1_i)),
            (pcbnew.VECTOR2I(x0_i + r_i, y1_i), pcbnew.VECTOR2I(x0_i, y1_i - r_i)),
            (pcbnew.VECTOR2I(x0_i, y0_i + r_i), pcbnew.VECTOR2I(x0_i + r_i, y0_i)),
        ]
        for p_start, p_end in pts:
            seg = pcbnew.PCB_SHAPE(board)
            seg.SetShape(pcbnew.SHAPE_T_SEGMENT)
            seg.SetLayer(pcbnew.Edge_Cuts)
            seg.SetStart(p_start)
            seg.SetEnd(p_end)
            seg.SetWidth(pcbnew.FromMM(0.1))
            board.Add(seg)

def get_or_create_net(board, net_name):
    net = board.FindNet(net_name)
    if net is None:
        net = pcbnew.NETINFO_ITEM(board, net_name)
        board.Add(net)
    return net

def add_track(board, start_pos, end_pos, layer, width_mm, net=None):
    t = pcbnew.PCB_TRACK(board)
    t.SetStart(start_pos)
    t.SetEnd(end_pos)
    t.SetLayer(layer)
    t.SetWidth(pcbnew.FromMM(width_mm))
    if net:
        t.SetNet(net)
    board.Add(t)
    return t

def add_via(board, pos, net=None, width_mm=0.6, drill_mm=0.3):
    v = pcbnew.PCB_VIA(board)
    v.SetPosition(pos)
    v.SetWidth(pcbnew.FromMM(width_mm))
    v.SetDrill(pcbnew.FromMM(drill_mm))
    if net:
        v.SetNet(net)
    board.Add(v)
    return v

def add_silkscreen_text(board, text, x_mm, y_mm, size_mm=1.0, layer=pcbnew.F_SilkS):
    t = pcbnew.PCB_TEXT(board)
    t.SetText(text)
    t.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x_mm), pcbnew.FromMM(y_mm)))
    t.SetLayer(layer)
    t.SetTextSize(pcbnew.VECTOR2I(pcbnew.FromMM(size_mm), pcbnew.FromMM(size_mm)))
    t.SetTextThickness(pcbnew.FromMM(0.15))
    board.Add(t)
    return t

def build_main_controller(output_path):
    print("Building Main_Controller_V01 PCB...")
    board = pcbnew.BOARD()

    # 1. Nets
    net_gnd = get_or_create_net(board, "GND")
    net_5v = get_or_create_net(board, "+5V")
    net_3v3 = get_or_create_net(board, "+3V3")
    net_sda = get_or_create_net(board, "SDA")
    net_scl = get_or_create_net(board, "SCL")
    net_htr_en = get_or_create_net(board, "HEATER_EN")
    net_htr_gate = get_or_create_net(board, "HEATER_GATE")
    net_htr_vcc = get_or_create_net(board, "HEATER_VCC")
    net_htr_ret = get_or_create_net(board, "HEATER_RETURN")
    net_gpio10 = get_or_create_net(board, "GPIO10_RES")

    # 2. Board Outline: 50.0 mm x 32.0 mm, origin at (100, 100)
    x0, y0 = 100.0, 100.0
    x1, y1 = 150.0, 132.0
    add_edge_cuts_rect(board, x0, y0, x1, y1, radius=1.0)

    # Silkscreen Titles (Clear from mounting holes)
    add_silkscreen_text(board, "Rice_SapFlow_V01", 108.5, 103.5, size_mm=1.1)
    add_silkscreen_text(board, "Main_Controller_V1.0", 108.5, 105.2, size_mm=0.8)

    # 3. Mounting Holes M3 (4 corners)
    hole_lib = os.path.join(FOOTPRINT_BASE, 'MountingHole.pretty')
    holes_pos = [(104.0, 104.0), (146.0, 104.0), (104.0, 128.0), (146.0, 128.0)]
    for i, (hx, hy) in enumerate(holes_pos):
        h = pcbnew.FootprintLoad(hole_lib, 'MountingHole_3.2mm_M3')
        h.SetReference(f"H{i+1}")
        h.SetValue("M3")
        h.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(hx), pcbnew.FromMM(hy)))
        board.Add(h)

    # 4. ESP32-C3 Super Mini Socket (2x 1x8 2.54mm pin headers)
    # Pitch between rows: 17.78 mm (700 mil). Center X = 125.0 mm.
    # Left header X = 116.11 mm, Right header X = 133.89 mm.
    # Vertically centered: Pin 1 at Y = 106.0 mm, Pin 8 at Y = 123.78 mm
    sock_lib = os.path.join(FOOTPRINT_BASE, 'Connector_PinSocket_2.54mm.pretty')
    u1_left = pcbnew.FootprintLoad(sock_lib, 'PinSocket_1x08_P2.54mm_Vertical')
    u1_left.SetReference("U1_L")
    u1_left.SetValue("ESP32-C3_SuperMini_Left")
    u1_left.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(116.11), pcbnew.FromMM(106.0)))
    board.Add(u1_left)

    u1_right = pcbnew.FootprintLoad(sock_lib, 'PinSocket_1x08_P2.54mm_Vertical')
    u1_right.SetReference("U1_R")
    u1_right.SetValue("ESP32-C3_SuperMini_Right")
    u1_right.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(133.89), pcbnew.FromMM(106.0)))
    board.Add(u1_right)

    # Assign nets to U1_L (Pins 1 to 8: 5V, GND, 3V3, IO0, IO1, IO2, IO3, IO4)
    u1_l_nets = {
        '1': net_5v,
        '2': net_gnd,
        '3': net_3v3,
        '4': net_sda,
        '5': net_scl,
        '7': net_htr_en
    }
    for p in u1_left.Pads():
        if p.GetNumber() in u1_l_nets:
            p.SetNet(u1_l_nets[p.GetNumber()])

    # Assign nets to U1_R (Pin 14 = IO10 Reserved)
    # Note: 1x8 pins are numbered 1-8. Pin 14 of Super Mini corresponds to Pin 6 of right header (IO10)
    for p in u1_right.Pads():
        if p.GetNumber() == '6':  # IO10
            p.SetNet(net_gpio10)

    # 5. Decoupling Capacitors
    c_lib = os.path.join(FOOTPRINT_BASE, 'Capacitor_SMD.pretty')
    # C1 (10uF 0805, 5V)
    c1 = pcbnew.FootprintLoad(c_lib, 'C_0805_2012Metric')
    c1.SetReference("C1")
    c1.SetValue("10uF")
    c1.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(110.0), pcbnew.FromMM(105.0)))
    for p in c1.Pads():
        if p.GetNumber() == '1': p.SetNet(net_5v)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
    board.Add(c1)

    # C2 (100nF 0603, 5V)
    c2 = pcbnew.FootprintLoad(c_lib, 'C_0603_1608Metric')
    c2.SetReference("C2")
    c2.SetValue("100nF")
    c2.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(112.5), pcbnew.FromMM(105.0)))
    for p in c2.Pads():
        if p.GetNumber() == '1': p.SetNet(net_5v)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
    board.Add(c2)

    # C3 (10uF 0805, 3.3V)
    c3 = pcbnew.FootprintLoad(c_lib, 'C_0805_2012Metric')
    c3.SetReference("C3")
    c3.SetValue("10uF")
    c3.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(110.0), pcbnew.FromMM(110.0)))
    for p in c3.Pads():
        if p.GetNumber() == '1': p.SetNet(net_3v3)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
    board.Add(c3)

    # C4 (100nF 0603, 3.3V)
    c4 = pcbnew.FootprintLoad(c_lib, 'C_0603_1608Metric')
    c4.SetReference("C4")
    c4.SetValue("100nF")
    c4.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(112.5), pcbnew.FromMM(110.0)))
    for p in c4.Pads():
        if p.GetNumber() == '1': p.SetNet(net_3v3)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
    board.Add(c4)

    # 6. I2C Pull-Up Resistors R1 & R2 (4.7k 0603 to 3.3V)
    r_lib = os.path.join(FOOTPRINT_BASE, 'Resistor_SMD.pretty')
    r1 = pcbnew.FootprintLoad(r_lib, 'R_0603_1608Metric')
    r1.SetReference("R1")
    r1.SetValue("4.7k")
    r1.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(110.5), pcbnew.FromMM(115.0)))
    for p in r1.Pads():
        if p.GetNumber() == '1': p.SetNet(net_3v3)
        elif p.GetNumber() == '2': p.SetNet(net_sda)
    board.Add(r1)

    r2 = pcbnew.FootprintLoad(r_lib, 'R_0603_1608Metric')
    r2.SetReference("R2")
    r2.SetValue("4.7k")
    r2.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(110.5), pcbnew.FromMM(118.0)))
    for p in r2.Pads():
        if p.GetNumber() == '1': p.SetNet(net_3v3)
        elif p.GetNumber() == '2': p.SetNet(net_scl)
    board.Add(r2)

    # 7. Solder Jumper SJ1 (3-pad: 1=3.3V, 2=HEATER_VCC, 3=5V)
    jmp_lib = os.path.join(FOOTPRINT_BASE, 'Jumper.pretty')
    sj1 = pcbnew.FootprintLoad(jmp_lib, 'SolderJumper-3_P1.3mm_Open_Pad1.0x1.5mm_NumberLabels')
    sj1.SetReference("SJ1")
    sj1.SetValue("3V3/5V")
    sj1.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(139.0), pcbnew.FromMM(109.0)))
    for p in sj1.Pads():
        if p.GetNumber() == '1': p.SetNet(net_3v3)
        elif p.GetNumber() == '2': p.SetNet(net_htr_vcc)
        elif p.GetNumber() == '3': p.SetNet(net_5v)
    board.Add(sj1)
    add_silkscreen_text(board, "SJ1: 1=3V3 2=VCC 3=5V", 135.0, 106.5, size_mm=0.8)

    # 8. AO3400A Low-Side Switch Circuit
    # MOSFET Q1 (SOT-23: 1=Gate, 2=Source, 3=Drain)
    sot_lib = os.path.join(FOOTPRINT_BASE, 'Package_TO_SOT_SMD.pretty')
    q1 = pcbnew.FootprintLoad(sot_lib, 'SOT-23')
    q1.SetReference("Q1")
    q1.SetValue("AO3400A")
    q1.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(139.0), pcbnew.FromMM(118.0)))
    for p in q1.Pads():
        if p.GetNumber() == '1': p.SetNet(net_htr_gate)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
        elif p.GetNumber() == '3': p.SetNet(net_htr_ret)
    board.Add(q1)

    # R3 (100 ohm series gate damping resistor)
    r3 = pcbnew.FootprintLoad(r_lib, 'R_0603_1608Metric')
    r3.SetReference("R3")
    r3.SetValue("100R")
    r3.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(137.0), pcbnew.FromMM(122.5)))
    for p in r3.Pads():
        if p.GetNumber() == '1': p.SetNet(net_htr_en)
        elif p.GetNumber() == '2': p.SetNet(net_htr_gate)
    board.Add(r3)

    # R4 (100k pull-down to GND)
    r4 = pcbnew.FootprintLoad(r_lib, 'R_0603_1608Metric')
    r4.SetReference("R4")
    r4.SetValue("100k")
    r4.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(140.5), pcbnew.FromMM(122.5)))
    for p in r4.Pads():
        if p.GetNumber() == '1': p.SetNet(net_htr_gate)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
    board.Add(r4)

    # 9. FPC Connector J1 (6P 0.5mm Horizontal Flip-Lock)
    # Positioned at bottom center, opening facing bottom edge
    fpc_lib = os.path.join(FOOTPRINT_BASE, 'Connector_FFC-FPC.pretty')
    j1 = pcbnew.FootprintLoad(fpc_lib, 'Hirose_FH12-6S-0.5SH_1x06-1MP_P0.50mm_Horizontal')
    j1.SetReference("J1")
    j1.SetValue("FPC-0.5-6P")
    j1.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(125.0), pcbnew.FromMM(128.5)))
    # Rotate 180 degrees so cable enters from the bottom edge
    j1.SetOrientationDegrees(180)
    j1_nets = {
        '1': net_3v3,
        '2': net_gnd,
        '3': net_sda,
        '4': net_scl,
        '5': net_htr_vcc,
        '6': net_htr_ret,
        'MP': net_gnd
    }
    for p in j1.Pads():
        if p.GetNumber() in j1_nets:
            p.SetNet(j1_nets[p.GetNumber()])
    board.Add(j1)
    add_silkscreen_text(board, "J1: 1=3V3 2=GND 3=SDA 4=SCL 5=VCC 6=RET", 112.0, 131.0, size_mm=0.7)

    # 10. Test Points TP1 to TP6
    tp_lib = os.path.join(FOOTPRINT_BASE, 'TestPoint.pretty')
    tps = [
        ("TP1", "5V", net_5v, 145.5, 107.0),
        ("TP2", "3V3", net_3v3, 145.5, 110.5),
        ("TP3", "GND", net_gnd, 145.5, 114.0),
        ("TP4", "SDA", net_sda, 145.5, 117.5),
        ("TP5", "SCL", net_scl, 145.5, 121.0),
        ("TP6", "HTR_RET", net_htr_ret, 145.5, 124.5),
    ]
    for ref, val, net, tpx, tpy in tps:
        tp = pcbnew.FootprintLoad(tp_lib, 'TestPoint_Pad_D1.0mm')
        tp.SetReference(ref)
        tp.SetValue(val)
        tp.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(tpx), pcbnew.FromMM(tpy)))
        for p in tp.Pads():
            p.SetNet(net)
        board.Add(tp)
        add_silkscreen_text(board, val, tpx - 3.2, tpy - 0.4, size_mm=0.7)

    # 11. Traces & Routing
    # Default trace width: 0.25 mm (10 mil), Power trace width: 0.635 mm (25 mil)
    # I2C Pull-up connections:
    p_3v3_r1 = r1.FindPadByNumber('1').GetPosition()
    p_3v3_r2 = r2.FindPadByNumber('1').GetPosition()
    add_track(board, p_3v3_r1, p_3v3_r2, pcbnew.F_Cu, 0.25, net_3v3)

    p_sda_r1 = r1.FindPadByNumber('2').GetPosition()
    p_u1_sda = u1_left.FindPadByNumber('4').GetPosition()
    add_track(board, p_sda_r1, pcbnew.VECTOR2I(p_u1_sda.x - pcbnew.FromMM(2.0), p_sda_r1.y), pcbnew.F_Cu, 0.25, net_sda)
    add_track(board, pcbnew.VECTOR2I(p_u1_sda.x - pcbnew.FromMM(2.0), p_sda_r1.y), p_u1_sda, pcbnew.F_Cu, 0.25, net_sda)

    p_scl_r2 = r2.FindPadByNumber('2').GetPosition()
    p_u1_scl = u1_left.FindPadByNumber('5').GetPosition()
    add_track(board, p_scl_r2, pcbnew.VECTOR2I(p_u1_scl.x - pcbnew.FromMM(2.0), p_scl_r2.y), pcbnew.F_Cu, 0.25, net_scl)
    add_track(board, pcbnew.VECTOR2I(p_u1_scl.x - pcbnew.FromMM(2.0), p_scl_r2.y), p_u1_scl, pcbnew.F_Cu, 0.25, net_scl)

    # Heater Gate Routing (U1_L Pin 7 -> R3 -> Q1 Gate)
    p_u1_htr_en = u1_left.FindPadByNumber('7').GetPosition()
    p_r3_in = r3.FindPadByNumber('1').GetPosition()
    add_track(board, p_u1_htr_en, pcbnew.VECTOR2I(p_u1_htr_en.x + pcbnew.FromMM(3.0), p_u1_htr_en.y), pcbnew.F_Cu, 0.25, net_htr_en)
    add_track(board, pcbnew.VECTOR2I(p_u1_htr_en.x + pcbnew.FromMM(3.0), p_u1_htr_en.y), pcbnew.VECTOR2I(p_r3_in.x - pcbnew.FromMM(2.0), p_r3_in.y), pcbnew.F_Cu, 0.25, net_htr_en)
    add_track(board, pcbnew.VECTOR2I(p_r3_in.x - pcbnew.FromMM(2.0), p_r3_in.y), p_r3_in, pcbnew.F_Cu, 0.25, net_htr_en)

    p_r3_out = r3.FindPadByNumber('2').GetPosition()
    p_r4_gate = r4.FindPadByNumber('1').GetPosition()
    p_q1_gate = q1.FindPadByNumber('1').GetPosition()
    add_track(board, p_r3_out, p_r4_gate, pcbnew.F_Cu, 0.25, net_htr_gate)
    add_track(board, p_r3_out, p_q1_gate, pcbnew.F_Cu, 0.25, net_htr_gate)

    # Power routing (SJ1 to J1 Pin 5 HEATER_VCC, 25 mil / 0.635 mm)
    p_sj1_vcc = sj1.FindPadByNumber('2').GetPosition()
    p_j1_vcc = j1.FindPadByNumber('5').GetPosition()
    mid_vcc = pcbnew.VECTOR2I(p_sj1_vcc.x, p_j1_vcc.y - pcbnew.FromMM(3.0))
    add_track(board, p_sj1_vcc, mid_vcc, pcbnew.F_Cu, 0.635, net_htr_vcc)
    add_track(board, mid_vcc, pcbnew.VECTOR2I(p_j1_vcc.x, p_j1_vcc.y - pcbnew.FromMM(3.0)), pcbnew.F_Cu, 0.635, net_htr_vcc)
    add_track(board, pcbnew.VECTOR2I(p_j1_vcc.x, p_j1_vcc.y - pcbnew.FromMM(3.0)), p_j1_vcc, pcbnew.F_Cu, 0.635, net_htr_vcc)

    # HEATER_RETURN routing (Q1 Drain -> J1 Pin 6, 25 mil / 0.635 mm)
    p_q1_drain = q1.FindPadByNumber('3').GetPosition()
    p_j1_ret = j1.FindPadByNumber('6').GetPosition()
    mid_ret = pcbnew.VECTOR2I(p_q1_drain.x, p_j1_ret.y - pcbnew.FromMM(2.0))
    add_track(board, p_q1_drain, mid_ret, pcbnew.F_Cu, 0.635, net_htr_ret)
    add_track(board, mid_ret, pcbnew.VECTOR2I(p_j1_ret.x, p_j1_ret.y - pcbnew.FromMM(2.0)), pcbnew.F_Cu, 0.635, net_htr_ret)
    add_track(board, pcbnew.VECTOR2I(p_j1_ret.x, p_j1_ret.y - pcbnew.FromMM(2.0)), p_j1_ret, pcbnew.F_Cu, 0.635, net_htr_ret)

    # 12. Bottom Layer GND Plane
    zone_gnd = pcbnew.ZONE(board)
    zone_gnd.SetNet(net_gnd)
    zone_gnd.SetLayer(pcbnew.B_Cu)
    chain = pcbnew.SHAPE_LINE_CHAIN()
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x0 + 0.5), pcbnew.FromMM(y0 + 0.5)))
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x1 - 0.5), pcbnew.FromMM(y0 + 0.5)))
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x1 - 0.5), pcbnew.FromMM(y1 - 0.5)))
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x0 + 0.5), pcbnew.FromMM(y1 - 0.5)))
    chain.SetClosed(True)
    poly = pcbnew.SHAPE_POLY_SET()
    poly.AddOutline(chain)
    zone_gnd.SetOutline(poly)
    board.Add(zone_gnd)

    pcbnew.SaveBoard(output_path, board)
    print(f"Main_Controller_V01 saved to {output_path}")

def build_sensor_fpc(variant_name, spacing_mm, probe_len_mm, probe_w_mm, output_path):
    print(f"Building {variant_name} (spacing={spacing_mm}mm, len={probe_len_mm}mm)...")
    board = pcbnew.BOARD()

    # Nets
    net_gnd = get_or_create_net(board, "GND")
    net_3v3 = get_or_create_net(board, "+3V3")
    net_sda = get_or_create_net(board, "SDA")
    net_scl = get_or_create_net(board, "SCL")
    net_htr_vcc = get_or_create_net(board, "HEATER_VCC")
    net_htr_ret = get_or_create_net(board, "HEATER_RETURN")

    # Board Outline (Lance Needle with Tapered Tip & Stiffened Tail)
    # Origin at x = 100.0 mm, centerline at y = 100.0 mm
    # Tail: x = 100.0 to 110.0 mm, width = 3.6 mm (y = 98.2 to 101.8 mm)
    # Lance probe: x = 110.0 to 100.0 + probe_len_mm
    # Tip: tapered triangular non-invasive insertion tip
    x_tail_start = 100.0
    x_tail_end = 110.0
    x_probe_end = 100.0 + probe_len_mm
    x_tip = x_probe_end + 3.0
    half_w = probe_w_mm / 2.0
    y_center = 100.0
    y_top = y_center - half_w
    y_bot = y_center + half_w

    probe_pts = [
        # Tail
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_start), pcbnew.FromMM(y_center - 1.8)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end), pcbnew.FromMM(y_center - 1.8))),
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end), pcbnew.FromMM(y_center - 1.8)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end + 1.0), pcbnew.FromMM(y_top))),
        # Top lance edge
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end + 1.0), pcbnew.FromMM(y_top)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_probe_end), pcbnew.FromMM(y_top))),
        # Tapered needle tip
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_probe_end), pcbnew.FromMM(y_top)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_tip), pcbnew.FromMM(y_center))),
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_tip), pcbnew.FromMM(y_center)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_probe_end), pcbnew.FromMM(y_bot))),
        # Bottom lance edge
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_probe_end), pcbnew.FromMM(y_bot)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end + 1.0), pcbnew.FromMM(y_bot))),
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end + 1.0), pcbnew.FromMM(y_bot)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end), pcbnew.FromMM(y_center + 1.8))),
        # Tail bottom edge
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_end), pcbnew.FromMM(y_center + 1.8)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_start), pcbnew.FromMM(y_center + 1.8))),
        # Tail left edge
        (pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_start), pcbnew.FromMM(y_center + 1.8)),
         pcbnew.VECTOR2I(pcbnew.FromMM(x_tail_start), pcbnew.FromMM(y_center - 1.8))),
    ]
    for p_start, p_end in probe_pts:
        seg = pcbnew.PCB_SHAPE(board)
        seg.SetShape(pcbnew.SHAPE_T_SEGMENT)
        seg.SetLayer(pcbnew.Edge_Cuts)
        seg.SetStart(p_start)
        seg.SetEnd(p_end)
        seg.SetWidth(pcbnew.FromMM(0.1))
        board.Add(seg)

    # Silkscreen Title & Info
    add_silkscreen_text(board, f"{variant_name} d={spacing_mm}mm", x_tail_end + 2.0, y_center - half_w - 0.5, size_mm=0.7)

    # 1. Gold Finger Connector J1_FPC (6P 0.5mm)
    # Placed on tail at x = 101.5 to 105.0 mm
    # 6 fingers, pitch 0.50 mm: y = y_center + (i - 2.5) * 0.50 mm
    fp_tail = pcbnew.FOOTPRINT(board)
    fp_tail.SetReference("J1_FPC")
    fp_tail.SetValue("GoldFinger_6P_0.5mm")
    fp_tail.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(103.5), pcbnew.FromMM(y_center)))

    pin_nets = [net_3v3, net_gnd, net_sda, net_scl, net_htr_vcc, net_htr_ret]
    for i in range(6):
        pad = pcbnew.PAD(fp_tail)
        pad.SetNumber(str(i + 1))
        pad.SetShape(pcbnew.PAD_SHAPE_RECT)
        pad.SetSize(pcbnew.VECTOR2I(pcbnew.FromMM(2.5), pcbnew.FromMM(0.30)))
        pad.SetAttribute(pcbnew.PAD_ATTRIB_SMD)
        lset = pcbnew.LSET()
        lset.AddLayer(pcbnew.F_Cu)
        lset.AddLayer(pcbnew.F_Mask)  # Exposed ENIG Gold Finger
        pad.SetLayerSet(lset)
        pad_y = (i - 2.5) * 0.50
        pad.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(103.5), pcbnew.FromMM(y_center + pad_y)))
        pad.SetNet(pin_nets[i])
        fp_tail.Add(pad)
    board.Add(fp_tail)

    # 2. Sensing Components Placement along plant sap flow:
    # Linear order: TMP117_UP (U1) -> PTC (R_HEAT) -> TMP117_DOWN (U2)
    # Center PTC at x = 122.0 mm
    x_ptc = 122.0
    x_up = x_ptc - spacing_mm
    x_down = x_ptc + spacing_mm

    # Footprint libraries
    son_lib = os.path.join(FOOTPRINT_BASE, 'Package_SON.pretty')
    r_lib = os.path.join(FOOTPRINT_BASE, 'Resistor_SMD.pretty')
    c_lib = os.path.join(FOOTPRINT_BASE, 'Capacitor_SMD.pretty')

    # A. TMP117_UP (U1, address 0x48, ADD0 -> GND)
    u1 = pcbnew.FootprintLoad(son_lib, 'WSON-6-1EP_2x2mm_P0.65mm_EP1x1.6mm')
    u1.SetReference("U1")
    u1.SetValue("TMP117_UP_0x48")
    u1.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x_up), pcbnew.FromMM(y_center)))
    u1.SetOrientationDegrees(90)

    # Process TMP117 pads:
    # Retain exposed thermal pad 7 as copper + mask, REMOVE solder paste opening and KEEP FLOATING!
    # Remove any unnumbered paste apertures.
    pads_to_remove = []
    for p in u1.Pads():
        p_num = p.GetNumber()
        if p_num == '':
            pads_to_remove.append(p)
        elif p_num == '1': p.SetNet(net_scl)
        elif p_num == '2': p.SetNet(net_gnd)
        elif p_num == '4': p.SetNet(net_gnd)  # ADD0 -> GND => 0x48
        elif p_num == '5': p.SetNet(net_3v3)
        elif p_num == '6': p.SetNet(net_sda)
        elif p_num == '7':
            # Exposed Thermal Pad: ensure NO paste, NO net (floating)
            lset = p.GetLayerSet()
            if lset.Contains(pcbnew.F_Paste):
                lset.RemoveLayer(pcbnew.F_Paste)
                p.SetLayerSet(lset)
    for p in pads_to_remove:
        u1.Remove(p)
    board.Add(u1)

    # Decoupling Cap C1 (100nF 0402) for U1
    c1 = pcbnew.FootprintLoad(c_lib, 'C_0402_1005Metric')
    c1.SetReference("C1")
    c1.SetValue("100nF")
    c1.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x_up - 1.8), pcbnew.FromMM(y_center)))
    c1.SetOrientationDegrees(90)
    for p in c1.Pads():
        if p.GetNumber() == '1': p.SetNet(net_3v3)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
    board.Add(c1)

    # B. PRF18BC471RB5RB PTC Heater (R_HEAT, 0603, 470 ohm)
    r_heat = pcbnew.FootprintLoad(r_lib, 'R_0603_1608Metric')
    r_heat.SetReference("R_HEAT")
    r_heat.SetValue("PTC_470R")
    r_heat.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x_ptc), pcbnew.FromMM(y_center)))
    r_heat.SetOrientationDegrees(90)
    for p in r_heat.Pads():
        if p.GetNumber() == '1': p.SetNet(net_htr_vcc)
        elif p.GetNumber() == '2': p.SetNet(net_htr_ret)
    board.Add(r_heat)

    # C. TMP117_DOWN (U2, address 0x49, ADD0 -> 3.3V)
    u2 = pcbnew.FootprintLoad(son_lib, 'WSON-6-1EP_2x2mm_P0.65mm_EP1x1.6mm')
    u2.SetReference("U2")
    u2.SetValue("TMP117_DN_0x49")
    u2.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x_down), pcbnew.FromMM(y_center)))
    u2.SetOrientationDegrees(90)

    pads_to_remove = []
    for p in u2.Pads():
        p_num = p.GetNumber()
        if p_num == '':
            pads_to_remove.append(p)
        elif p_num == '1': p.SetNet(net_scl)
        elif p_num == '2': p.SetNet(net_gnd)
        elif p_num == '4': p.SetNet(net_3v3)  # ADD0 -> 3.3V => 0x49
        elif p_num == '5': p.SetNet(net_3v3)
        elif p_num == '6': p.SetNet(net_sda)
        elif p_num == '7':
            # Exposed Thermal Pad: ensure NO paste, NO net (floating)
            lset = p.GetLayerSet()
            if lset.Contains(pcbnew.F_Paste):
                lset.RemoveLayer(pcbnew.F_Paste)
                p.SetLayerSet(lset)
    for p in pads_to_remove:
        u2.Remove(p)
    board.Add(u2)

    # Decoupling Cap C2 (100nF 0402) for U2
    c2 = pcbnew.FootprintLoad(c_lib, 'C_0402_1005Metric')
    c2.SetReference("C2")
    c2.SetValue("100nF")
    c2.SetPosition(pcbnew.VECTOR2I(pcbnew.FromMM(x_down + 1.8), pcbnew.FromMM(y_center)))
    c2.SetOrientationDegrees(90)
    for p in c2.Pads():
        if p.GetNumber() == '1': p.SetNet(net_3v3)
        elif p.GetNumber() == '2': p.SetNet(net_gnd)
    board.Add(c2)

    # 3. Symmetrical Signal & Power Traces
    # Symmetrical routing on top and bottom of probe centerline
    # Trace width: 0.15 mm (6 mil), power trace width: 0.20 mm (8 mil)
    # Strictly NO ground copper fill or power planes between PTC and TMP117s!
    trace_w = 0.15
    # SCL trace (Top side, y = y_center - 1.1 mm)
    add_track(board, pcbnew.VECTOR2I(pcbnew.FromMM(105.0), pcbnew.FromMM(y_center - 1.0)),
              pcbnew.VECTOR2I(pcbnew.FromMM(x_down + 1.2), pcbnew.FromMM(y_center - 1.0)),
              pcbnew.F_Cu, trace_w, net_scl)
    # SDA trace (Top side, y = y_center - 0.7 mm)
    add_track(board, pcbnew.VECTOR2I(pcbnew.FromMM(105.0), pcbnew.FromMM(y_center - 0.65)),
              pcbnew.VECTOR2I(pcbnew.FromMM(x_down + 1.2), pcbnew.FromMM(y_center - 0.65)),
              pcbnew.F_Cu, trace_w, net_sda)

    # 3V3 trace (Top side, y = y_center - 1.35 mm)
    add_track(board, pcbnew.VECTOR2I(pcbnew.FromMM(105.0), pcbnew.FromMM(y_center - 1.35)),
              pcbnew.VECTOR2I(pcbnew.FromMM(x_down + 1.2), pcbnew.FromMM(y_center - 1.35)),
              pcbnew.F_Cu, 0.20, net_3v3)

    # GND trace (Bottom side, y = y_center + 1.35 mm)
    add_track(board, pcbnew.VECTOR2I(pcbnew.FromMM(105.0), pcbnew.FromMM(y_center + 1.35)),
              pcbnew.VECTOR2I(pcbnew.FromMM(x_down + 1.2), pcbnew.FromMM(y_center + 1.35)),
              pcbnew.F_Cu, 0.20, net_gnd)

    # Heater Power Traces (HEATER_VCC and HEATER_RETURN to PTC at center)
    add_track(board, pcbnew.VECTOR2I(pcbnew.FromMM(105.0), pcbnew.FromMM(y_center + 0.65)),
              pcbnew.VECTOR2I(pcbnew.FromMM(x_ptc), pcbnew.FromMM(y_center + 0.65)),
              pcbnew.F_Cu, 0.25, net_htr_vcc)
    add_track(board, pcbnew.VECTOR2I(pcbnew.FromMM(105.0), pcbnew.FromMM(y_center + 1.0)),
              pcbnew.VECTOR2I(pcbnew.FromMM(x_ptc), pcbnew.FromMM(y_center + 1.0)),
              pcbnew.F_Cu, 0.25, net_htr_ret)

    # 4. Strict Thermal Keepout Zone (Rule Area preventing copper pour in sensing region)
    keepout_z = pcbnew.ZONE(board)
    keepout_z.SetIsRuleArea(True)
    keepout_z.SetDoNotAllowZoneFills(True)
    chain = pcbnew.SHAPE_LINE_CHAIN()
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x_up - 2.5), pcbnew.FromMM(y_top)))
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x_down + 2.5), pcbnew.FromMM(y_top)))
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x_down + 2.5), pcbnew.FromMM(y_bot)))
    chain.Append(pcbnew.VECTOR2I(pcbnew.FromMM(x_up - 2.5), pcbnew.FromMM(y_bot)))
    chain.SetClosed(True)
    poly = pcbnew.SHAPE_POLY_SET()
    poly.AddOutline(chain)
    keepout_z.SetOutline(poly)
    lset = pcbnew.LSET()
    lset.AddLayer(pcbnew.F_Cu)
    lset.AddLayer(pcbnew.B_Cu)
    keepout_z.SetLayerSet(lset)
    board.Add(keepout_z)

    pcbnew.SaveBoard(output_path, board)
    print(f"{variant_name} saved to {output_path}")

def generate_kicad_pro(pro_path, proj_name):
    content = f'''{{
  "meta": {{
    "filename": "{proj_name}.kicad_pro",
    "version": 1
  }},
  "schematic": {{
    "annotate_start_num": 1,
    "drawing": {{
      "dashed_lines_dash_length_ratio": 12.0,
      "dashed_lines_gap_length_ratio": 3.0,
      "default_line_thickness": 0.1524,
      "default_text_size": 1.27,
      "field_names": [],
      "intersheets_ref_own_page": false,
      "intersheets_ref_prefix": "",
      "intersheets_ref_short": false,
      "intersheets_ref_show": false,
      "intersheets_ref_suffix": "",
      "junction_size_choice": 3,
      "pin_symbol_size": 0.0,
      "text_offset_ratio": 0.2
    }}
  }},
  "board": {{
    "design_settings": {{
      "rules": {{
        "min_clearance": 0.15,
        "min_track_width": 0.15
      }}
    }}
  }}
}}'''
    with open(pro_path, 'w', encoding='utf-8') as f:
        f.write(content)

if __name__ == '__main__':
    root_dir = '/Users/zhangshuxuan/Documents/antigravity/peaceful-noether/Rice_SapFlow_V01'

    # 1. Main Controller
    main_dir = os.path.join(root_dir, 'Main_Controller_V01')
    os.makedirs(main_dir, exist_ok=True)
    main_pcb = os.path.join(main_dir, 'Main_Controller_V01.kicad_pcb')
    main_pro = os.path.join(main_dir, 'Main_Controller_V01.kicad_pro')
    build_main_controller(main_pcb)
    generate_kicad_pro(main_pro, 'Main_Controller_V01')

    # 2. Sensor FPC Variants (2mm, 3mm, 4mm)
    fpc_base = os.path.join(root_dir, 'Sensor_FPC_V01')
    variants = [
        ('Sensor_FPC_2MM', 2.0, 36.0, 3.2),
        ('Sensor_FPC_3MM', 3.0, 40.0, 3.5),
        ('Sensor_FPC_4MM', 4.0, 45.0, 3.8),
    ]
    for vname, spacing, plen, pw in variants:
        vdir = os.path.join(fpc_base, vname)
        os.makedirs(vdir, exist_ok=True)
        vpcb = os.path.join(vdir, f'{vname}.kicad_pcb')
        vpro = os.path.join(vdir, f'{vname}.kicad_pro')
        build_sensor_fpc(vname, spacing, plen, pw, vpcb)
        generate_kicad_pro(vpro, vname)

    print("All KiCad boards and projects generated successfully!")
